<?php $__env->startSection('content'); ?>


<main class="main">
    <div class="page-header" style="background-image: url(images/page-header.jpg)">
        <h1 class="page-title">Search</h1>
    </div>
    <div class="page-content mb-10">
        <div class="container">       
        <div class="container home-suc-msg">
                <?php if(Session::get('success')): ?> <br> <div class="sxs"><?php echo e(Session::get('success')); ?></div> <?php endif; ?>
                <style>
                .sxs{
                    color: #212f21;
                    padding: 15px 95px;
                    background-color: #cfe470;
                    font-size: 14px;
                    font-weight: bold;
                    width: fit-content;
                    border-radius: 25px;
                }
                .home-suc-msg {
                    text-align: -webkit-center;
                }
                </style>
            </div>
            <br>
            <div class="row main-content-wrap gutter-lg">
                <div class="col-lg-12 main-content">

                    <div class="row cols-2 cols-sm-3 product-wrapper">
                        <?php echo $__env->make('customer.front.common.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    </div>
                    
                    <nav class="toolbox toolbox-pagination">
                        <p class="show-info">Showing <span><?php echo e((($products->currentPage() - 1) * $products->perPage() + 1)); ?> to <?php echo e((($products->currentPage() - 1) * 4 + $products->count())); ?> of <?php echo e($products->total()); ?></span> Products</p>
                        <ul class="pagination">
                            <?php echo e($products->links()); ?>

                        </ul>
                    </nav>
                    
                </div>
            </div>
        </div>
    </div>
</main>

<style>
li.with-ul ul {
    padding-left: 20px;
}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/customer/front/search.blade.php ENDPATH**/ ?>