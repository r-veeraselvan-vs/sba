<?php $__env->startSection('content'); ?>


<main class="main">
    <div class="page-content mb-10">
        <div class="container">
            <ul class="breadcrumb breadcrumb-sm">
            </ul>
            <!-- End Breadcrumb -->
            <div class="row main-content-wrap gutter-lg">
                <aside class="col-lg-3 sidebar sidebar-fixed shop-sidebar sticky-sidebar-wrapper">
                    <div class="sidebar-overlay">
                        <a class="sidebar-close" href="#"><i class="d-icon-times"></i></a>
                    </div>
                    <div class="sidebar-content">
                        <div class="sticky-sidebar">
                            <div class="widget widget-collapsible">
                                <h3 class="widget-title">All <?php echo e($menu); ?></h3>
                                <ul class="widget-body filter-items search-ul">
                                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $men): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php switch($menu):
                                            case ('categories'): ?>
                                                <li class="with-ul  <?php if($men->slug == $slug): ?> show <?php endif; ?> ">
                                                    <a href="<?php echo e(route('products', [ 'menu' => $menu, 'slug' => $men->slug, 'sub_slug' => 'all' ])); ?>"><?php echo e($men->category); ?><i class="fas fa-chevron-down"></i></a>
                                                    <ul style="<?php if($men->slug == $slug): ?> display: block; <?php else: ?> display: none; <?php endif; ?>">
                                                        <?php $__currentLoopData = $men->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li class="<?php if($sub->slug == $sub_slug): ?> show <?php endif; ?>"><a href="<?php echo e(route('products', [ 'menu' => $menu, 'slug' => $men->slug, 'sub_slug' => $sub->slug ])); ?>"><?php echo e($sub->subcategory); ?></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </li>
                                            <?php break; ?>
                                        <?php endswitch; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </aside>
                <div class="col-lg-9 main-content">
                    <div class="">
                        <img src="<?php echo e($banner); ?>" class="img-fluid" alt="" height="500px">
                        <!-- style="background-image: url(<?php echo e($banner); ?>); background-color: #f2f2f3;  width: 1280px; height: 330px; " -->
                        <!-- <div class="banner-content">
                            <h4 class="banner-subtitle mb-2  text-body text-uppercase ls-m font-weight-normal">
                                Donald Shop</h4>
                            <h1 class="banner-title font-weight-normal text-uppercase"><strong
                                    class="ls-m">Banner</strong> With<br /> Sidebar</h1>
                            <p class="font-primary lh-1 ls-m mb-0">Simple and Fresh ShopStyle</p>
                        </div> -->
                    </div>

                    <?php if(Session::get('success')): ?> <p class="sxs"><?php echo e(Session::get('success')); ?></p> <?php endif; ?>
                    <style>
                    .sxs{
                        color: #212f21;
                        padding: 15px 95px;
                        background-color: #cfe470;
                        font-size: 14px;
                        font-weight: bold;
                        width: fit-content;
                        border-radius: 25px;
                    }
                    </style>

                    <h4 style="padding: 10px; text-align: center;"><?php echo e($title); ?></h4>

                <!-- filter menu -->
                <nav class="toolbox sticky-toolbox sticky-content fix-top">
                        <div class="toolbox-left">
                            <a href="#"
                                class="toolbox-item left-sidebar-toggle btn btn-sm btn-outline btn-primary d-lg-none">Filters<i
                                    class="d-icon-arrow-right"></i></a>
                        </div>
                    </nav>
                <!-- filter menu -->

                    <div class="row cols-2 cols-sm-3 product-wrapper">
                        <?php echo $__env->make('customer.front.common.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    </div>
                    
                    <nav class="toolbox toolbox-pagination">
                        <p class="show-info">Showing <span><?php echo e((($products->currentPage() - 1) * $products->perPage() + 1)); ?> to <?php echo e((($products->currentPage() - 1) * 4 + $products->count())); ?> of <?php echo e($products->total()); ?></span> Products</p>
                        <ul class="pagination">
                            <?php echo e($products->links()); ?>

                        </ul>
                    </nav>
                    
                </div>
            </div>
        </div>
    </div>
</main>


<style>
li.with-ul ul {
    padding-left: 20px;
}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/customer/front/products.blade.php ENDPATH**/ ?>