<div style="width=100%; background-color:#d9d9d9; padding:20px">
    <p>Hi <?php echo e($data['name']); ?>,</p>

    <p>Your order has been <?php echo e($data['delivery_status']); ?>.</p>
    
    <br>
    Regards, <br>
    Admin Team.
</div>
<?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/email/order-status.blade.php ENDPATH**/ ?>