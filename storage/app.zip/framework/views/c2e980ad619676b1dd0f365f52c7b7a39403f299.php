<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 193px;">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Product Price Update</h1>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-5">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Choose File (.csv) </h3>
                        </div>
                        <form role="form" method="post" class="col-md-12"  enctype="multipart/form-data" action="<?php echo e(route('product.import')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">File</label>
                                <input type="file" accept=".csv" required name="csv_file" class="form-control" required>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Update Price</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="card">
                        <div class="card-body">
                            <div class="callout callout-success">
                                <h5>Validations!</h5>
                            </div>
                            <?php if(count($validate) > 0): ?>
                                <br>
                                <div class="alert alert-warning">
                                <h5><i class="icon fas fa-ban"></i> Validation Error!</h5>
                                    <?php $__currentLoopData = $validate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><b>Item [<?php echo e($i); ?>]</b></p>
                                        <?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($value); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                            <?php if($d){ echo '<br><pre>'; print_r($d); echo '</pre>'; } ?>
                        </div>
                    </div>
                </div>
            </div>	
        </div>
    </section>
  </div>


  <?php $__env->stopSection(); ?>
  

                    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/product/product_import.blade.php ENDPATH**/ ?>