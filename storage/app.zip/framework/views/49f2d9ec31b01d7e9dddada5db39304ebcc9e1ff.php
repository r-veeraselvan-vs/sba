<div class="tab-pane <?php if($tab == 'image'): ?> active <?php endif; ?>" id="image">
    <div class="add-button">
        <button type="button" onclick="add_image();" class="btn btn-primary btn-sm">Add Image</button>
    </div>
    <br>
    <div>
        <form action="<?php echo e(route('product.image.update')); ?>" enctype="multipart/form-data" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
            <input type="hidden" name="tab" value="image">
            <table id="image_table" class="table">
                <tr id="-1">
                    <th>Image</th>
                    <th>Preview</th>
                    <th>Matrix 1</th>
                    <th>Display Order</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ikey => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($ikey); ?>">
                        <td>                                                            
                            <input type="hidden" name="data[<?php echo e($ikey); ?>][id]" value="<?php echo e($image->id); ?>">
                            <input type="hidden" name="data[<?php echo e($ikey); ?>][product_id]" value="<?php echo e($image->product_id); ?>">
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" onChange="display_image_image(this, <?php echo e($ikey); ?>)" name="data[<?php echo e($ikey); ?>][image]" class="custom-file-input" >
                                    <label class="custom-file-label" for="exampleInputFile">Change Image</label>
                                </div>
                            </div>
                            <input type="hidden" name="data[<?php echo e($ikey); ?>][old_image]" value="<?php echo e($image->image); ?>">
                        </td>
                        <td>
                            <a href="<?php echo e($image->ImageUrl); ?>" target="_blank" rel="noopener noreferrer">
                                <img src="<?php echo e($image->ImageUrl); ?>" alt="" width="40px" height="40px" id="preview_image_image<?php echo e($ikey); ?>">
                            </a>
                        </td>
                        <td>
                            <select class="form-control" name="data[<?php echo e($ikey); ?>][matrix1]">
                                <option value=""></option>
                                <?php $__currentLoopData = $matrix_ones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matrix_one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($matrix_one); ?>" <?php if($image->matrix1 == $matrix_one): ?> selected <?php endif; ?>><?php echo e($matrix_one); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td>
                            <input class="form-control" type="number" name="data[<?php echo e($ikey); ?>][display_order]" value="<?php echo e($image->display_order); ?>" required>
                        </td>
                        <td>
                            <select class="form-control" name="data[<?php echo e($ikey); ?>][status]" required>
                                <option value="Active" <?php if($image->status == 'Active'): ?> selected <?php endif; ?>>Active</option>
                                <option value="Inactive" <?php if($image->status == 'Inactive'): ?> selected <?php endif; ?>>Inactive</option>
                            </select>
                        </td>
                        <td>
                            &nbsp; <a href="<?php echo e(route('product.image.delete', [ 'id' => $image->id ])); ?>"><span class="badge bg-danger"><i class="fas fa-trash"></i></span></a>
                        </td>
                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="card-footer" style="text-align: right;">
                <button type="submit" class="btn btn-primary btn-sm">Update</button>
            </div>
        </form>
    </div>
    <!-- history -->
    <!-- history -->
</div>
<script>
    function add_image(){
        var ikey = parseInt($('#image_table tr:last-child').attr('id')) + 1;
        var display_order = ikey + 1;
        var add_image = '<tr id="'+ikey+'">'+
                        '<td>'+
                            '<input type="hidden" name="data['+ikey+'][id]" value="0">'+
                            '<input type="hidden" name="data['+ikey+'][product_id]" value="<?php echo e($product->id); ?>">'+
                            '<div class="input-group">'+
                                '<div class="custom-file">'+
                                    '<input type="file" onChange="display_image_image(this, '+ikey+')" name="data['+ikey+'][image]" class="custom-file-input" required >'+
                                    '<label class="custom-file-label" for="exampleInputFile">Choose Image</label>'+
                                '</div>'+
                            '</div>'+
                        '</td>'+
                        '<td>'+
                            '<img src="/images/no_image.png" alt="" width="40px" height="40px" id="preview_image_image'+ikey+'">'+
                        '</td>'+
                        '<td>'+
                            '<select class="form-control" name="data['+ikey+'][matrix1]">'+
                                '<option value=""></option>'+
                                '<?php $__currentLoopData = $matrix_ones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matrix_one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'+
                                '<option value="<?php echo e($matrix_one); ?>"><?php echo e($matrix_one); ?></option>'+
                                '<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>'+
                            '</select>'+
                        '</td>'+
                        '<td>'+
                            '<input class="form-control" type="number" name="data['+ikey+'][display_order]" value="'+display_order+'" required>'+
                        '</td>'+
                        '<td>'+
                            '<select class="form-control" name="data['+ikey+'][status]" required>'+
                                '<option value="Active">Active</option>'+
                                '<option value="Inactive">Inactive</option>'+
                            '</select>'+
                        '</td>'+
                        '<td>'+
                            '&nbsp; <a onclick="remove_image('+ikey+');" id="delete_image_'+ikey+'"><span class="badge bg-danger"><i class="fas fa-trash"></i></span></a>'+
                        '</td>'+
                    '</tr>';
                    $('#image_table').append(add_image);
    }
    function remove_image(key){
        $('#delete_image_'+key).closest('tr').remove();
    }
</script>

<script>
    function triggerClickPromoImage(e) {
        document.querySelector('#image').click();
    }
    function display_image_image(e, id) {
        if (e.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e){
            document.querySelector('#preview_image_image'+id).setAttribute('src', e.target.result);
            }
            reader.readAsDataURL(e.files[0]);
        }
    }
</script><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/product/components/image.blade.php ENDPATH**/ ?>