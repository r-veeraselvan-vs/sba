<!-- Root element of PhotoSwipe. Must have class pswp. -->
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

<!-- Background of PhotoSwipe. It's a separate element as animating opacity is faster than rgba(). -->
<div class="pswp__bg"></div>

<!-- Slides wrapper with overflow:hidden. -->
<div class="pswp__scroll-wrap">

    <!-- Container that holds slides.
    PhotoSwipe keeps only 3 of them in the DOM to save memory.
    Don't modify these 3 pswp__item elements, data is added later on. -->
    <div class="pswp__container">
        <div class="pswp__item"></div>
        <div class="pswp__item"></div>
        <div class="pswp__item"></div>
    </div>

    <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
    <div class="pswp__ui pswp__ui--hidden">

        <div class="pswp__top-bar">

            <!--  Controls are self-explanatory. Order can be changed. -->

            <div class="pswp__counter"></div>

            <button class="pswp__button pswp__button--close" aria-label="Close (Esc)"></button>
            <button class="pswp__button pswp__button--zoom" aria-label="Zoom in/out"></button>

            <div class="pswp__preloader">
                <div class="loading-spin"></div>
            </div>
        </div>

        <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
            <div class="pswp__share-tooltip"></div>
        </div>

        <button class="pswp__button--arrow--left" aria-label="Previous (arrow left)"></button>
        <button class="pswp__button--arrow--right" aria-label="Next (arrow right)"></button>

        <div class="pswp__caption">
            <div class="pswp__caption__center"></div>
        </div>
    </div>
</div>
</div>


<div class="mobile-menu-wrapper">
    <div class="mobile-menu-overlay">
    </div>
    <!-- End of Overlay -->
    <a class="mobile-menu-close" href="#"><i class="d-icon-times"></i></a>
    <!-- End of CloseButton -->
    <div class="mobile-menu-container scrollable">
        <form action="<?php echo e(route('product.search')); ?>" class="input-wrapper">
            <input type="text" class="form-control" name="search" autocomplete="off"
                placeholder="Search your Products..." />
            <button class="btn btn-search" type="submit">
                <i class="d-icon-search"></i>
            </button>
        </form>
        <!-- End of Search Form -->
        <ul class="mobile-menu mmenu-anim">
            <li class="<?php if(request()->segment(1) == ''): ?> active <?php endif; ?>">
                <a href="/">Home</a>
            </li>
           
            <!-- About Us -->
            <li class="<?php if(request()->segment(1) == 'about-us'): ?> active <?php endif; ?>">
                <a href="/about-us">About Us</a>
            </li>

            <!-- Contact Us -->
            <li class="<?php if(request()->segment(1) == 'contact-us'): ?> active <?php endif; ?>">
                <a href="/contact-us">Contact Us</a>
            </li>

            <?php
                $slug = \App\Category::where('id', '1')->value('slug');
            ?>
            
            <li class="<?php if(request()->segment(2) == 'categories'): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $slug, 'sub_slug' => 'all' ])); ?>">Categories</a>
            </li>

        </ul>
        <!-- End of MobileMenu -->
        <ul class="mobile-menu mmenu-anim">
                <li class="<?php if(request()->segment(1) == 'cart'): ?> active <?php endif; ?>">
                    <a href="/cart">My Cart</a>
                </li>
                <?php if(Auth::user()): ?>
                    <li><a href="<?php echo e(route('customer.profile')); ?>" class="rv"><?php echo e(Auth::user()->name); ?></a></li>
                <?php else: ?>
                    <li><a href="/login" class="rv">Login</a></li>
                <?php endif; ?>
            </ul>
        <!-- End of MobileMenu -->
    </div>
</div><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/layouts/front/mobile-menu.blade.php ENDPATH**/ ?>