<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Users</h1>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Edit Admin / Executive</h3>
              </div>
              <form role="form" method="post" class="col-md-6" action="<?php echo e(route('user.update')); ?>">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter Name" value="<?php echo e(old('name', $user->name)); ?>">
                    <?php if($errors->has('name')): ?> 
                        <span class="error" for="site" style="display: inline-block;color:red;"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Mobile</label>
                    <input type="text" class="form-control" name="mobile" placeholder="Enter Mobile" value="<?php echo e(old('mobile', $user->mobile)); ?>">
                    <?php if($errors->has('mobile')): ?> 
                        <span class="error" for="site" style="display: inline-block;color:red;"><?php echo e($errors->first('mobile')); ?></span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" name="email" placeholder="Enter email" value="<?php echo e(old('email', $user->email)); ?>" readonly>
                    <?php if($errors->has('email')): ?> 
                        <span class="error" for="site" style="display: inline-block;color:red;"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Role</label>
                    <select class="form-control" name="role" >
                        <option></option>
                        <option value="Super Admin" <?php echo e(('Super Admin' == $user->role) ? 'selected' : ''); ?>>Super Admin</option>
                        <option value="Admin" <?php echo e(('Admin' == $user->role) ? 'selected' : ''); ?>>Admin</option>
                        <option value="Executive" <?php echo e(('Executive' == $user->role) ? 'selected' : ''); ?>>Executive</option>
                    </select>
                    <?php if($errors->has('role')): ?> 
                        <span class="error" for="site" style="display: inline-block;color:red;"><?php echo e($errors->first('role')); ?></span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                      <label for="exampleInputPassword1">Status</label>
                      <select class="form-control" name="status" >
                          <option value="Active" <?php if('Active' == $user->status): ?> selected <?php endif; ?>>Active</option>
                          <option value="Inactive" <?php if('Inactive' == $user->status): ?> selected <?php endif; ?>>Inactive</option>
                      </select>
                  </div>
                </div>

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/user/edit_user.blade.php ENDPATH**/ ?>