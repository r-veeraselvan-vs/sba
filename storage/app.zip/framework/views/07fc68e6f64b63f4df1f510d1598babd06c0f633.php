<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Delivery Slot Edit</h1>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Deliver Slot</h3>
              </div>
              <form role="form" method="post" class="col-md-6" action="<?php echo e(route('delivery.slot.update')); ?>">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($slot->id); ?>">
                <div class="card-body">
                 
                    <div class="form-group">
                        <label for="exampleInputPassword1">Day</label>
                        <select class="form-control" name="day" required> 
                            <option value="Monday" <?php if('Monday' == $slot->day): ?> selected <?php endif; ?>>Monday</option>
                            <option value="Tuesday" <?php if('Tuesday' == $slot->day): ?> selected <?php endif; ?>>Tuesday</option>
                            <option value="Wednesday" <?php if('Wednesday' == $slot->day): ?> selected <?php endif; ?>>Wednesday</option>
                            <option value="Thursday" <?php if('Thursday' == $slot->day): ?> selected <?php endif; ?>>Thursday</option>
                            <option value="Friday" <?php if('Friday' == $slot->day): ?> selected <?php endif; ?>>Friday</option>
                            <option value="Saturday" <?php if('Saturday' == $slot->day): ?> selected <?php endif; ?>>Saturday</option>
                            <option value="Sunday" <?php if('Sunday' == $slot->day): ?> selected <?php endif; ?>>Sunday</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="exampleInputEmail1">Start</label>
                        <input type="time" required class="form-control" name="start" value="<?php echo e($slot->start); ?>" placeholder="Enter Start">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputEmail1">End</label>
                        <input type="time" required class="form-control" name="end" value="<?php echo e($slot->end); ?>" placeholder="Enter End">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputEmail1">Deliveries</label>
                        <input type="number" required class="form-control" name="deliveries" value="<?php echo e($slot->deliveries); ?>" placeholder="Enter Deliveries">
                    </div>

                  <div class="form-group">
                      <label for="exampleInputPassword1">Status</label>
                      <select class="form-control" name="status" >
                          <option value="Active" <?php if('Active' == $slot->status): ?> selected <?php endif; ?>>Active</option>
                          <option value="Inactive" <?php if('Inactive' == $slot->status): ?> selected <?php endif; ?>>Inactive</option>
                      </select>
                  </div>
                </div>

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/delivery-slot/delivery_slot_edit.blade.php ENDPATH**/ ?>