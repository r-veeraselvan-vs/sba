<?php $__env->startSection('content'); ?>

<main class="main">
            <div class="page-header" style="background-image: url(images/page-header.jpg)">
                <h1 class="page-title">About Us</h1>
            </div>
            <div class="page-content mt-10 pt-7">
                <section class="about-section">
                    <div class="container">
                        <h2 class="title mb-lg-9">About Madurai Kadai</h2>
                        <div class="row mb-10">
                            <div class="col-md-6">
                                <img class="w-100 mb-4 appear-animate"
                                    data-animation-options="{'name':'fadeInLeftShorter'}"
                                    src="images/subpages/about.jpg" alt="Donald Store" width="587" height="517"
                                    style="position: sticky; top: 2rem;">
                            </div>
                            <div class="col-md-6 order-md-first pt-md-5">
                                <p class="text-uppercase text-grey mb-0">Who we are</p>
                                <h5 class="lh-1 ls-m">Has glorious history</h5>
                                <p class="font-primary ">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. </p>
 
                               <!--  <div class="row pl-xl-6 pr-xl-8 mb-6">
                                    <div class="counter text-primary text-center col-sm-4 col-md-6 col-lg-4">
                                        <span class="count-to" data-to="35" data-refresh-interval="50">0</span>
                                        <h5 class="count-title">Business Year</h5>
                                    </div>
                                    <div class="counter text-primary text-center col-sm-4 col-md-6 col-lg-4">
                                        <span class="count-to" data-to="50" data-refresh-interval="50">0</span>
                                        <h5 class="count-title">Design Brands</h5>
                                    </div>
                                    <div class="counter text-primary text-center col-sm-4 col-md-12 col-lg-4">
                                        <span class="count-to" data-to="130" data-refresh-interval="50">0</span>
                                        <h5 class="count-title">Team Members</h5>
                                    </div>
                                </div> -->
                                <!-- <ul
                                    class="list list-circle row cols-sm-2 cols-md-1 cols-xl-2 font-weight-bold text-dark font-primary mb-4">
                                    <li class="appear-animate"
                                        data-animation-options="{'name': 'fadeInRightShorter','delay':'.4s'}"><i
                                            class="fa fa-check"></i>Pellentesque ultricies nibh</li>
                                    <li class="appear-animate" data-animation-options="{'name': 'fadeInRightShorter'}">
                                        <i class="fa fa-check"></i>Pellentesque ultricies nibh</li>
                                    <li class="appear-animate"
                                        data-animation-options="{'name': 'fadeInRightShorter','delay':'.5s'}"><i
                                            class="fa fa-check"></i>Ultricies nibh pellen</li>
                                    <li class="appear-animate"
                                        data-animation-options="{'name': 'fadeInRightShorter','delay':'.3s'}"><i
                                            class="fa fa-check"></i>Ultricies nibh pellen</li>
                                </ul> -->
                            </div>
                        </div>
                    </div>
                </section>
                <!-- End About Section-->

            </div>
        </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/customer/front/about-us.blade.php ENDPATH**/ ?>