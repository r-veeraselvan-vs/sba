<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Vendors</h1>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Edit Vendor </h3>
              </div>
              <form role="form" method="post" class="col-md-6" action="<?php echo e(route('vendor.update')); ?>">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter Name" value="<?php echo e(old('name', $user->name)); ?>" onkeypress="return /[a-z,0-9, ]/i.test(event.key)" required>
                    <?php if($errors->has('name')): ?> 
                        <span class="error" for="site" style="display: inline-block;color:red;"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                  </div>
                   <div class="form-group">
                    <label for="exampleInputEmail1">Address</label>
                    <textarea   class="form-control" name="address" placeholder="Enter Address" value="<?php echo e(old('address')); ?>" required><?php echo e($user->address); ?></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Contact Number</label>
                    <input type="text" class="form-control" name="mobile" placeholder="Enter Mobile" value="<?php echo e(old('mobile', $user->mobile)); ?>"  minlength="10" maxlength="10"   onkeypress="return /[0-9, ]/i.test(event.key)"  required>
                    <?php if($errors->has('mobile')): ?> 
                        <span class="error" for="site" style="display: inline-block;color:red;"><?php echo e($errors->first('mobile')); ?></span>
                    <?php endif; ?>
                  </div>
                    <div class="form-group">
                    <label for="exampleInputEmail1">GSTIN</label>
                    <input type="text" class="form-control" name="gst" placeholder="Enter GSTIN" value="<?php echo e($user->gst); ?>" required>
                   
                  </div>
                   
                </div>

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/vendor/edit.blade.php ENDPATH**/ ?>