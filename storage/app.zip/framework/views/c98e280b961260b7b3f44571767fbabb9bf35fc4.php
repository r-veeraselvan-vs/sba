<div class="tab-pane <?php if($tab == 'edit'): ?> active <?php endif; ?>" id="edit">
    <div>
        <form role="form" method="post" action="<?php echo e(route('delivery.area.update')); ?>">
            <div class="row">
                <?php echo csrf_field(); ?>
                <div class="col-md-6">
                    <input type="hidden" name="id" value="<?php echo e($area->id); ?>">
                    <input type="hidden" name="tab" value="<?php echo e($tab); ?>">
                    <div class="card-body">

                        <div class="form-group">
                            <label for="exampleInputEmail1">Pin Code</label>
                            <input type="text" required class="form-control" name="pin_code"
                                value="<?php echo e($area->pin_code); ?>" placeholder="Enter Pin Code">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Area</label>
                            <input type="text" required class="form-control" name="area" value="<?php echo e($area->area); ?>"
                                placeholder="Enter Area">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Delivery Charge</label>
                            <input type="number" required class="form-control" name="delivery_charge" min="0"
                                value="<?php echo e($area->delivery_charge); ?>" placeholder="Enter Delivery Charge">
                        </div>

                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
            </div>
                <div class="col-md-6">
                    <div class="card-body">

                        <div class="form-group">
                            <label for="exampleInputEmail1">Days</label>
                            <table class="table">
                                <tr>
                                    <th class="head-th">SUN</th>
                                    <th class="head-th">MON</th>
                                    <th class="head-th">TUE</th>
                                    <th class="head-th">WED</th>
                                    <th class="head-th">THU</th>
                                    <th class="head-th">FRI</th>
                                    <th class="head-th">SAT</th>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="checkbox" class="form-control" name="days[sunday]"
                                            <?php if(in_array('sunday', $area->days->pluck('day')->toArray())): ?> checked
                                        <?php endif; ?>>
                                    </td>
                                    <td>
                                        <input type="checkbox" class="form-control" name="days[monday]"
                                            <?php if(in_array('monday', $area->days->pluck('day')->toArray())): ?> checked
                                        <?php endif; ?>>
                                    </td>
                                    <td>
                                        <input type="checkbox" class="form-control" name="days[tuesday]"
                                            <?php if(in_array('tuesday', $area->days->pluck('day')->toArray())): ?> checked
                                        <?php endif; ?>>
                                    </td>
                                    <td>
                                        <input type="checkbox" class="form-control" name="days[wednesday]"
                                            <?php if(in_array('wednesday', $area->days->pluck('day')->toArray())): ?> checked
                                        <?php endif; ?>>
                                    </td>
                                    <td>
                                        <input type="checkbox" class="form-control" name="days[thursday]"
                                            <?php if(in_array('thursday', $area->days->pluck('day')->toArray())): ?> checked
                                        <?php endif; ?>>
                                    </td>
                                    <td>
                                        <input type="checkbox" class="form-control" name="days[friday]"
                                            <?php if(in_array('friday', $area->days->pluck('day')->toArray())): ?> checked
                                        <?php endif; ?>>
                                    </td>
                                    <td>
                                        <input type="checkbox" class="form-control" name="days[saturday]"
                                            <?php if(in_array('saturday', $area->days->pluck('day')->toArray())): ?> checked
                                        <?php endif; ?>>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPassword1">Status</label>
                            <select class="form-control" name="status">
                                <option value="Active" <?php if('Active'==$area->status): ?> selected <?php endif; ?>>Active</option>
                                <option value="Inactive" <?php if('Inactive'==$area->status): ?> selected <?php endif; ?>>Inactive
                                </option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/delivery-area/components/edit.blade.php ENDPATH**/ ?>