<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
    $url = route('product.details', [ 'price_id' => (@$product->one_price->id ? @$product->one_price->id : 'all'), 'slug' => $product->slug ]);
?>


            <!-- Offer Price Validation  -->
            <?php if(@$product->one_price->offer_percentage): ?>   
                <?php
                    $date = strtotime(date("Y-m-d"));
                    $start_date = strtotime(@$product->one_price->start_date);
                    $end_date = strtotime(@$product->one_price->end_date);
                    if($date >= $start_date && $date <= $end_date){
                        $price = @$product->one_price->offer_price;
                        $strike_price = @$product->one_price->price;
                        $show = true;
                    }else{
                        $price = @$product->one_price->price;
                        $strike_price = 0;
                        $show = false;
                    }
                ?>
            <?php else: ?>
                <?php
                    $price = @$product->one_price->price;
                    $strike_price = 0;
                    $show = false;
                ?>
            <?php endif; ?>
            <!-- Offer Price Validation  -->

<div class="product-wrap col-md-3">
    <div class="product shadow-media">
        <figure class="product-media">
            <a href="<?php echo e($url); ?>">
                <img src="<?php echo e($product->ThumbnailUrl); ?>" alt="product" width="280" height="315">
            </a>
            <?php if(@$product->one_price->offer_percentage && $show == true): ?>
            <div class="product-label-group">
                <label class="product-label label-sale"><?php echo e(@$product->one_price->offer_percentage); ?>% Off</label>
            </div>
            <?php endif; ?>
            <div class="product-action-vertical">
                <a onclick="$('#cart_form_<?php echo e($product->id); ?>').submit();" class="btn-product-icon btn-cart" data-toggle="modal" data-target="#addCartModal"
                    title="Add to cart"><i class="d-icon-bag"></i></a>
            </div>
            <form action="<?php echo e(route('cart.add')); ?>" method="post" id="cart_form_<?php echo e($product->id); ?>">
                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                <input type="hidden" name="product_price_id" value="<?php echo e(@$product->one_price->id); ?>">
                <input type="hidden" name="price" value="<?php echo e($price); ?>">
                <input type="hidden" name="offer_price" value="<?php echo e($show == true ? $price : 0); ?>">
                <input type="hidden" name="offer_expiry_date" value="<?php echo e($show == true ? @$product->one_price->end_date : ''); ?>">
                <input type="hidden" name="weight" value="<?php echo e(@$product->one_price->weight); ?>">
                <input type="hidden" name="quantity" id="quantity" value="1">   
                <input type="hidden" name="gst" value="<?php echo e($product->gst); ?>">                            
            </form>
        </figure>
        <div class="product-details">
            <?php
                $heart = in_array($product->id, $wishlists);
                $type = ($heart == true) ? 'false' : 'true';
            ?> 
            <a href="<?php echo e(route('wishlist.add', [ 'product_id' => $product->id, 'type' => $type ] )); ?>" class="" title="<?php if($heart): ?> Remove from wishlist <?php else: ?> Add to wishlist <?php endif; ?>"><i style="color:red; float:right" class=" <?php if($heart): ?> d-icon-heart-full <?php else: ?> d-icon-heart <?php endif; ?>"></i></a>
            <div class="product-cat">
                <a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $product->category->slug, 'sub_slug' => 'all' ])); ?>"><?php echo e($product->category->category); ?></a>
            </div>
            <h3 class="product-name">
                <a href="<?php echo e($url); ?>"><?php echo e($product->name); ?> <?php echo e($heart); ?></a>
            </h3>


                <div class="product-price">
                    <ins class="new-price">₹ <?php echo e(number_format($price, 2)); ?></ins>
                    <?php if(@$product->one_price->offer_percentage  && $show == true): ?> 
                    <del class="old-price">₹ <?php echo e(number_format($strike_price, 2)); ?></del>
                    <?php endif; ?>
                </div>
            <div class="ratings-container">
                <?php
                    $average_ratings = $product->average_ratings;
                    $star = $average_ratings * 20;
                ?>
                <div class="ratings-full">
                    <span class="ratings" style="width:<?php echo e($star); ?>%"></span>
                    <span class="tooltiptext tooltip-top"><?php echo e($average_ratings); ?></span>
                </div>
                <!-- <a href="#" class="rating-reviews">( 6 reviews )</a> -->
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/customer/front/common/product.blade.php ENDPATH**/ ?>