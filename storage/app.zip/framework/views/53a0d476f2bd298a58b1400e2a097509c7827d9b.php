<div class="tab-pane <?php if($tab == 'slot'): ?> active <?php endif; ?>" id="slot">
    <div class="add-button">
        <button type="button" onclick="add_slot();" class="btn btn-primary btn-sm">Add Delivery Slot</button>
    </div>
    <br>
    <div>
        <form action="<?php echo e(route('delivery.area.slot.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($area->id); ?>">
            <input type="hidden" name="tab" value="slot">
            <table id="slot_table" class="table">
                <tr id="-1">
                    <th>Days</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Deliveries</th>
                    <th>Status</th>
                </tr>
                <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fkey => $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($fkey); ?>">
                        <td>                                                            
                            <input type="hidden" name="data[<?php echo e($fkey); ?>][id]" value="<?php echo e($slot->id); ?>">
                            <input type="hidden" name="data[<?php echo e($fkey); ?>][delivery_area_id]" value="<?php echo e($area->id); ?>">
                            <select class="form-control" name="data[<?php echo e($fkey); ?>][day]" required> 
                                <option value="Monday" <?php if('Monday' == $slot->day): ?> selected <?php endif; ?>>Monday</option>
                                <option value="Tuesday" <?php if('Tuesday' == $slot->day): ?> selected <?php endif; ?>>Tuesday</option>
                                <option value="Wednesday" <?php if('Wednesday' == $slot->day): ?> selected <?php endif; ?>>Wednesday</option>
                                <option value="Thursday" <?php if('Thursday' == $slot->day): ?> selected <?php endif; ?>>Thursday</option>
                                <option value="Friday" <?php if('Friday' == $slot->day): ?> selected <?php endif; ?>>Friday</option>
                                <option value="Saturday" <?php if('Saturday' == $slot->day): ?> selected <?php endif; ?>>Saturday</option>
                                <option value="Sunday" <?php if('Sunday' == $slot->day): ?> selected <?php endif; ?>>Sunday</option>
                            </select>
                        </td>
                        <td>    
                            <input type="time" required class="form-control" name="data[<?php echo e($fkey); ?>][start]" value="<?php echo e($slot->start); ?>" placeholder="Enter Start">
                        </td>
                        <td>
                            <input type="time" required class="form-control" name="data[<?php echo e($fkey); ?>][end]" value="<?php echo e($slot->end); ?>" placeholder="Enter End">
                        </td>
                        <td>
                            <input type="number" required class="form-control" name="data[<?php echo e($fkey); ?>][deliveries]" value="<?php echo e($slot->deliveries); ?>" placeholder="Enter Deliveries">
                        </td>
                        <td>
                            <select class="form-control" name="data[<?php echo e($fkey); ?>][status]" required>
                                <option value="Active" <?php if($slot->status == 'Active'): ?> selected <?php endif; ?>>Active</option>
                                <option value="Inactive" <?php if($slot->status == 'Inactive'): ?> selected <?php endif; ?>>Inactive</option>
                            </select>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="card-footer" style="text-align: right;">
                <button type="submit" class="btn btn-primary btn-sm">Update</button>
            </div>
        </form>
    </div>
    <!-- history -->
    
    <!-- history -->
</div>
<script>
    function add_slot(){
        var fkey = parseInt($('#slot_table tr:last-child').attr('id')) + 1;
        var display_order = fkey + 1;
        var add_slot = '<tr id="'+fkey+'">'+
                        '<td>'+
                            '<input type="hidden" name="data['+fkey+'][id]" value="0">'+
                            '<input type="hidden" name="data['+fkey+'][delivery_area_id]" value="<?php echo e($area->id); ?>">'+
                            '<select class="form-control" name="data['+fkey+'][day]" required>'+
                                '<option value=""></option>'+
                                '<option value="Monday">Monday</option>'+
                                '<option value="Tuesday">Tuesday</option>'+
                                '<option value="Wednesday">Wednesday</option>'+
                                '<option value="Thursday">Thursday</option>'+
                                '<option value="Friday">Friday</option>'+
                                '<option value="Saturday">Saturday</option>'+
                                '<option value="Sunday">Sunday</option>'+
                            '</select>'+
                        '</td>'+
                        '<td>'+
                            '<input class="form-control" type="time" name="data['+fkey+'][start]" value="" placeholder="Enter Start" required>'+
                        '</td>'+
                        '<td>'+
                            '<input class="form-control" type="time" name="data['+fkey+'][end]" value="" placeholder="Enter End" required>'+
                        '</td>'+
                        '<td>'+
                            '<input class="form-control" type="number" name="data['+fkey+'][deliveries]" value="" required>'+
                        '</td>'+
                        '<td>'+
                            '<div style="display: flex;">'+
                                '<select class="form-control" name="data['+fkey+'][status]" required>'+
                                    '<option value="Active">Active</option>'+
                                    '<option value="Inactive">Inactive</option>'+
                                '</select>'+
                                '&nbsp; <a onclick="remove_slot('+fkey+');" id="delete_slot_'+fkey+'"><span class="badge bg-danger"><i class="fas fa-trash"></i></span></a>'+
                            '</div>'+
                        '</td>'+
                    '</tr>';
                    $('#slot_table').append(add_slot);
    }
    function remove_slot(key){
        $('#delete_slot_'+key).closest('tr').remove();
    }
</script><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/delivery-area/components/slot.blade.php ENDPATH**/ ?>