<div class="tab-pane <?php if($tab == 'specification'): ?> active <?php endif; ?>" id="specification">
    <div class="add-button">
        <button type="button" onclick="add_specification();" class="btn btn-primary btn-sm">Add Specification</button>
    </div>
    <br>
    <div>
        <form action="<?php echo e(route('product.specification.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
            <input type="hidden" name="tab" value="specification">
            <table id="specification_table" class="table">
                <tr id="-1">
                    <th>Name</th>
                    <th>Details</th>
                    <th>Display Order</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $product->specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skey => $specification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($skey); ?>">
                        <td>                                                            
                            <input type="hidden" name="data[<?php echo e($skey); ?>][id]" value="<?php echo e($specification->id); ?>">
                            <input type="hidden" name="data[<?php echo e($skey); ?>][product_id]" value="<?php echo e($specification->product_id); ?>">
                            <input class="form-control" type="text" name="data[<?php echo e($skey); ?>][name]" value="<?php echo e($specification->name); ?>" required>
                        </td>
                        <td>
                            
                        <input class="form-control" type="text" name="data[<?php echo e($skey); ?>][details]" value="<?php echo e($specification->details); ?>" required>
                        </td>
                        <td>
                            <input class="form-control" type="number" name="data[<?php echo e($skey); ?>][display_order]" value="<?php echo e($specification->display_order); ?>" required>
                        </td>
                        <td>
                            <select class="form-control" name="data[<?php echo e($skey); ?>][status]" required>
                                <option value="Active" <?php if($specification->status == 'Active'): ?> selected <?php endif; ?>>Active</option>
                                <option value="Inactive" <?php if($specification->status == 'Inactive'): ?> selected <?php endif; ?>>Inactive</option>
                            </select>
                        </td>
                        <td>
                            &nbsp; <a href="<?php echo e(route('product.specification.delete', [ 'id' => $specification->id ])); ?>"><span class="badge bg-danger"><i class="fas fa-trash"></i></span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="card-footer" style="text-align: right;">
                <button type="submit" class="btn btn-primary btn-sm">Update</button>
            </div>
        </form>
    </div>
    <!-- history -->
    
    <!-- history -->
</div>
<script>
    function add_specification(){
        var skey = parseInt($('#specification_table tr:last-child').attr('id')) + 1;
        var display_order = skey + 1;
        var add_specification = '<tr id="'+skey+'">'+
                        '<td>'+
                            '<input type="hidden" name="data['+skey+'][id]" value="0">'+
                            '<input type="hidden" name="data['+skey+'][product_id]" value="<?php echo e($product->id); ?>">'+
                            '<input class="form-control" type="text" name="data['+skey+'][name]" value="" required>'+
                        '</td>'+
                        '<td>'+
                            '<input class="form-control" type="text" name="data['+skey+'][details]" value="" required>'+
                        '</td>'+
                        '<td>'+
                            '<input class="form-control" type="number" name="data['+skey+'][display_order]" value="'+display_order+'" required>'+
                        '</td>'+
                        '<td>'+
                            '<select class="form-control" name="data['+skey+'][status]" required>'+
                                '<option value="Active">Active</option>'+
                                '<option value="Inactive">Inactive</option>'+
                            '</select>'+
                        '</td>'+
                        '<td>'+
                            '&nbsp; <a onclick="remove_specification('+skey+');" id="delete_specification_'+skey+'"><span class="badge bg-danger"><i class="fas fa-trash"></i></span></a>'+
                        '</td>'+
                    '</tr>';
                    $('#specification_table').append(add_specification);
    }
    function remove_specification(key){
        $('#delete_specification_'+key).closest('tr').remove();
    }
</script><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/product/components/specification.blade.php ENDPATH**/ ?>