<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Reviews List</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- /.content-header -->

    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="tab-content">

                    <!-- main Service -->
                    <div class="tab-pane active">
                        <table id="example1" class="table">
                            <thead>
                                <tr>
                                    <th>Sl No</th>
                                    <th>Product</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Reviews & Ratings</th>
                                    <th>Status</th>
                                    <th>Update Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php 
                                    $user = \App\User::where('id',$review->user_id)->first();
                                ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><?php echo e($review->product->name); ?></td>
                                    <td><?php echo e(ucfirst($user->name)); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <?php echo e($review->review); ?> <br>
                                        <div class="starRating star_<?php echo e($review->ratings); ?>">
                                            <span>(<?php echo e($review->ratings); ?>)</span></div>
                                    </td>
                                    <td><span
                                            class="right badge <?php if($review->status == 'Active'): ?> badge-success <?php elseif($review->status == 'Submitted'): ?> badge-info <?php else: ?> badge-danger <?php endif; ?>"><?php echo e($review->status); ?></span>
                                    </td>
                                    <td>
                                        <select name="status" id="status-<?php echo e($review->id); ?>"
                                            onChange="changeStatus(<?php echo e($review->product_id); ?>, <?php echo e($review->id); ?>)">
                                            <option <?php if($review->status == 'Submitted'): ?> selected <?php endif; ?>
                                                value="Submitted">Submitted</option>
                                            <option <?php if($review->status == 'Active'): ?> selected <?php endif; ?>
                                                value="Active">Active</option>
                                            <option <?php if($review->status == 'Inactive'): ?> selected <?php endif; ?>
                                                value="Inactive">Inactive</option>
                                        </select>
                                    </td>
                                    <td>
                                        <a
                                            href="<?php echo e(route('review.delete', [ 'product_id' => $review->product_id, 'id' => $review->id ])); ?>"><span
                                                class="badge bg-danger"><i class="fas fa-trash"></i></span></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
        </div>
    </div>

</div>

<script>
function changeStatus(product_id, id) {
    var status = $('#status-' + id).val();
    var url = "<?php echo e(url('admin/review/update')); ?>" + '/' + product_id + '/' + id + '/' + status;
    window.location = url;
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/reviews/review_list.blade.php ENDPATH**/ ?>