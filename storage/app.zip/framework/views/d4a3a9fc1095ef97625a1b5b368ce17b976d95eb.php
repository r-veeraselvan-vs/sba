<div class="tab-pane <?php if($tab == 'feature'): ?> active <?php endif; ?>" id="feature">
    <div class="add-button">
        <button type="button" onclick="add_feature();" class="btn btn-primary btn-sm">Add Feature</button>
    </div>
    <br>
    <div>
        <form action="<?php echo e(route('product.feature.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
            <input type="hidden" name="tab" value="feature">
            <table id="feature_table" class="table">
                <tr id="-1">
                    <th>Feature</th>
                    <th>Display Order</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $product->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fkey => $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="<?php echo e($fkey); ?>">
                        <td>                                                            
                            <input type="hidden" name="data[<?php echo e($fkey); ?>][id]" value="<?php echo e($feature->id); ?>">
                            <input type="hidden" name="data[<?php echo e($fkey); ?>][product_id]" value="<?php echo e($feature->product_id); ?>">
                            <input class="form-control" type="text" name="data[<?php echo e($fkey); ?>][feature]" value="<?php echo e($feature->feature); ?>" required>
                        </td>
                        <td>
                            <input class="form-control" type="number" name="data[<?php echo e($fkey); ?>][display_order]" value="<?php echo e($feature->display_order); ?>" required>
                        </td>
                        <td>
                            <select class="form-control" name="data[<?php echo e($fkey); ?>][status]" required>
                                <option value="Active" <?php if($feature->status == 'Active'): ?> selected <?php endif; ?>>Active</option>
                                <option value="Inactive" <?php if($feature->status == 'Inactive'): ?> selected <?php endif; ?>>Inactive</option>
                            </select>
                        </td>
                        <td>
                            &nbsp; <a href="<?php echo e(route('product.feature.delete', [ 'id' => $feature->id ])); ?>"><span class="badge bg-danger"><i class="fas fa-trash"></i></span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="card-footer" style="text-align: right;">
                <button type="submit" class="btn btn-primary btn-sm">Update</button>
            </div>
        </form>
    </div>
    <!-- history -->
    
    <!-- history -->
</div>
<script>
    function add_feature(){
        var fkey = parseInt($('#feature_table tr:last-child').attr('id')) + 1;
        var display_order = fkey + 1;
        var add_feature = '<tr id="'+fkey+'">'+
                        '<td>'+
                            '<input type="hidden" name="data['+fkey+'][id]" value="0">'+
                            '<input type="hidden" name="data['+fkey+'][product_id]" value="<?php echo e($product->id); ?>">'+
                            '<input class="form-control" type="text" name="data['+fkey+'][feature]" value="" required>'+
                        '</td>'+
                        '<td>'+
                            '<input class="form-control" type="number" name="data['+fkey+'][display_order]" value="'+display_order+'" required>'+
                        '</td>'+
                        '<td>'+
                            '<select class="form-control" name="data['+fkey+'][status]" required>'+
                                '<option value="Active">Active</option>'+
                                '<option value="Inactive">Inactive</option>'+
                            '</select>'+
                        '</td>'+
                        '<td>'+
                            '&nbsp; <a onclick="remove_feature('+fkey+');" id="delete_feature_'+fkey+'"><span class="badge bg-danger"><i class="fas fa-trash"></i></span></a>'+
                        '</td>'+
                    '</tr>';
                    $('#feature_table').append(add_feature);
    }
    function remove_feature(key){
        $('#delete_feature_'+key).closest('tr').remove();
    }
</script><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/product/components/feature.blade.php ENDPATH**/ ?>