<div class="sticky-footer sticky-content fix-bottom">
    <a href="/" class="sticky-link active">
        <i class="d-icon-home"></i>
        <span>Home</span>
    </a>
    <?php
        $slug = \App\Category::where('id', '1')->value('slug');
    ?>
    <a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $slug, 'sub_slug' => 'all' ])); ?>" class="sticky-link">
        <i class="d-icon-volume"></i>
        <span>Categories</span>
    </a>
    <a href="#" class="sticky-link">
        <i class="d-icon-heart"></i>
        <span>Wishlist</span>
    </a>
    <?php if(Auth::user()): ?>
        <a href="<?php echo e(route('customer.profile')); ?>" class="sticky-link">
            <i class="d-icon-user"></i>
            <span><?php echo e(Auth::user()->name); ?></span>
        </a>
    <?php else: ?>
        <a href="/login" class="sticky-link">
            <i class="d-icon-user"></i>
            <span>Login</span>
        </a>
    <?php endif; ?>
    <div class="dropdown cart-dropdown dir-up">
        <a href="/cart" class="sticky-link cart-toggle">
            <i class="d-icon-bag"></i>
            <span>Cart</span>
        </a>

        <!-- End of Cart Toggle -->

        <?php
            use App\Cart;
            if(Auth::user()){
                $user_id = \Auth::user()->id;
                $query = Cart::where('user_id', $user_id);
            }else{
                $session_id = \Session::getId();
                $query = Cart::where('session_id', $session_id);
            }
            $cart_count = $query->count();
            $cart_amount = $query->sum('amount');
            $cart_products = $query->with('product')->get();
        ?>

        <div class="dropdown-box">
            <?php if(count($cart_products) > 0): ?>
                <div class="product product-cart-header">
                    <span class="product-cart-counts"><?php echo e($cart_count); ?> items</span>
                    <span><a href="<?php echo e(route('cart')); ?>">View cart</a></span>
                </div>
                <div class="products scrollable">
                    <!-- End of Cart Product -->
                    <?php $__currentLoopData = $cart_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                        <?php 
                            $product_price = ($cp->offer_price > 0) ? $cp->offer_price : $cp->price;
                            $productUrl =  route('product.details', [ 'price_id' => $cp->product_price_id, 'slug' => $cp->product->slug ]);
                        ?>
                        <div class="product product-cart">
                            <div class="product-detail">
                                <a href="<?php echo e($productUrl); ?>" class="product-name"><?php echo e(@$cp->product->name); ?></a>
                                <div class="price-box">
                                    <span class="product-quantity"><?php echo e(@$cp->quantity); ?></span>
                                    <span class="product-price">₹ <?php echo e(number_format($product_price, 2)); ?></span>
                                </div>
                            </div>
                            <figure class="product-media">
                                <a href="<?php echo e($productUrl); ?>">
                                    <img src="<?php echo e(@$cp->product->ThumbnailUrl); ?>" alt="product" width="90" height="90" />
                                </a>
                                <a href="<?php echo e(route('cart.remove', [ 'cart_id' => $cp->id ])); ?>" class="btn btn-link btn-close">
                                    <i class="fas fa-times"></i>
                                </a>
                            </figure>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- End of Cart Product -->
                </div>
                <!-- End of Products  -->
                <div class="cart-total">
                    <label>Subtotal:</label>
                    <span class="price">₹<?php echo e(number_format($cart_amount, 2)); ?></span>
                </div>
            <?php else: ?>
                <h5>Your cart is Empty</h5>
            <?php endif; ?>
            <!-- End of Cart Total -->
            <div class="cart-action">
                <?php if(count($cart_products) > 0): ?>
                <a href="<?php echo e(route('cart.checkout')); ?>" class="btn btn-dark"><span>Checkout</span></a>
                <?php else: ?>
                <a href="/" class="btn btn-light"><span>Continue Shopping</span></a>
                <?php endif; ?>
            </div>
            <!-- End of Cart Action -->
        </div>
        <!-- End of Dropdown Box -->

    </div>
</div><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/layouts/front/sticky-footer.blade.php ENDPATH**/ ?>