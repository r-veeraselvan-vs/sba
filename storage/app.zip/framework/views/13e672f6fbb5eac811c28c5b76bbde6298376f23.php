<div class="tab-pane <?php if(Session::get('tab') != 'review'): ?> active in <?php endif; ?>" id="feature">
    <ul class="list-none">
        <?php $__currentLoopData = $product->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><label><?php echo e($feat->feature); ?></label></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/customer/front/common/features.blade.php ENDPATH**/ ?>