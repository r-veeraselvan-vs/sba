<?php $__env->startSection('content'); ?>
<main class="main account">
    <div class="page-header" style="background-image: url('images/page-header.jpg'); background-color: #3C63A4;">
        <h1 class="page-title"><?php echo e(Session::get('form')); ?> / <?php if(Session::get('form') == 'login'): ?> SignUp <?php else: ?> Login <?php endif; ?></h1>
    </div>
    <!-- End PageHeader -->
    <div class="col-md-12" >
        <div class="row login-form">
            <div class="login-popup col-md-6">
                <div class="form-box">
                    <h4>Login</h4>
                    <div class="tab-pane active" id="signin">
                        <form action="<?php echo e(route('login.new')); ?>" method="post">
                            <div class="form-group">
                                <label for="singin-email">Email address:</label>
                                <input type="email" class="form-control" id="singin-email" name="email"
                                    required />
                                    <?php if(Session::get('form') == 'login'): ?> 
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                    <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label for="singin-password">Password:</label>
                                <input type="password" class="form-control" id="singin-password"
                                    name="password" required />
                                    <?php if(Session::get('form') == 'login'): ?> 
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                    <?php endif; ?>
                            </div>
                            <div class="form-footer">
                                <div class="form-checkbox">
                                    <input type="checkbox" class="custom-checkbox" id="signin-remember"
                                        name="signin-remember" />
                                    <!-- <label class="form-control-label font-secondary" for="signin-remember">Remember me</label> -->
                                </div>
                                <a href="<?php echo e(url('password/reset')); ?>"
                                    class="lost-link font-secondary">Lost your password?</a>
                            </div>
                            <button class="btn btn-primary btn-block" type="submit">Sign in</button>
                        </form>
                        <div class="form-choice text-center">
                            <label class="font-secondary">Sign in with social account</label>
                            <div class="social-links">
                                <a href="<?php echo e(route('social.login', ['provider' => 'facebook'])); ?>" class="social-link social-facebook fab fa-facebook-f"></a>
                                <!-- <a href="<?php echo e(route('social.login', ['provider' => 'twitter'])); ?>" class="social-link social-twitter fab fa-twitter"></a> -->
                                <a href="<?php echo e(route('social.login', ['provider' => 'google'])); ?>" class="social-link social-google fab fa-google"></a>
                            </div>
                            <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div style="color:red;"><?php echo e($error); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <!-- Socialite Include -->
                     
                        <!-- Socialite Include -->
                    </div>
                </div>
            </div>
            <div class="login-popup col-md-6">
                <div class="form-box">
                    <h4>Sign Up</h4>
                    <div class="tab-pane active" id="register">
                        <form action="<?php echo e(route('register')); ?>" method="post">
                            <div class="form-group">
                                <label for="singin-email">Name:</label>
                                <input type="text" class="form-control" id="name" name="name"
                                    required />
                                    <?php if(Session::get('form') == 'signup'): ?> 
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                    <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="singin-email">Your email address:</label>
                                <input type="email" class="form-control" id="email" name="email"
                                    required />
                                    <?php if(Session::get('form') == 'signup'): ?> 
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                    <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="singin-email">Mobile Number:</label>
                                <input type="text" class="form-control" id="mobile" name="mobile"
                                    required />
                                    <?php if(Session::get('form') == 'signup'): ?> 
                                        <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                    <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label for="singin-password">Password:</label>
                                <input type="password" class="form-control" id="password"
                                    name="password" required />
                                    <?php if(Session::get('form') == 'signup'): ?> 
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                    <?php endif; ?>
                            </div>

                            <button class="btn btn-primary btn-block" type="submit">Sign up</button>
                        </form>
                        <!-- <div class="form-choice text-center">
                            <label class="font-secondary">Sign in with social account</label>
                            <div class="social-links">
                                <a href="#" class="social-link social-facebook fab fa-facebook-f"></a>
                                <a href="#" class="social-link social-twitter fab fa-twitter"></a>
                                <a href="#" class="social-link social-google fab fa-google"></a>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<style>
.login-popup{
    max-width: none;
}
</style>

<?php if(count($errors) > 0): ?>
<script type="text/javascript">
$(document).ready(function() {
    $('#exampleModal2').modal('show');
});
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>