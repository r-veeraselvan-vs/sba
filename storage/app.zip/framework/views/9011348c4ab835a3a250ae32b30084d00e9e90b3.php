<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Update Delivery Area</h1>
          </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
          <div class="row">
            
              	<div class="col-md-12">
					<div class="card">
						<div class="card-header p-2">
							<ul class="nav nav-pills">
								<li class="nav-item"><a class="nav-link <?php if($tab == 'edit'): ?> active <?php endif; ?>" href="#edit" data-toggle="tab">Edit</a></li>
								<li class="nav-item"><a class="nav-link <?php if($tab == 'slot'): ?> active <?php endif; ?>" href="#slot" data-toggle="tab">Delivery Slots</a></li>
							</ul>
						</div>
						<div class="card-body">
							<div class="tab-content">
								<!-- Edit Delivery Area -->
								<?php echo $__env->make('admin.delivery-area.components.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								<!-- Slot Delivery Area -->
								<?php echo $__env->make('admin.delivery-area.components.slot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
							</div>
						</div>
					</div>
				</div>

          </div>
        </div>
      </section>
  </div>
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/delivery-area/delivery_area_edit.blade.php ENDPATH**/ ?>