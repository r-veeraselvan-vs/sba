<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      
        <li class="nav-item">
            <a class="nav-link" role="button" 
                href="https://youthechef.com/web/autologin?email=<?php echo e(Auth::user()->email); ?>&api_token=token"

              >
                <i class="fas fa-sign-out-alt"> Back</i>
            </a>
        </li>
      
    </ul>
  </nav>
  <!-- /.navbar --><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/layouts/header.blade.php ENDPATH**/ ?>