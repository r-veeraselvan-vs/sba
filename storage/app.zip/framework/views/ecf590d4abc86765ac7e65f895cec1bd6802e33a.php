<footer class="footer appear-animate">
    <div class="container">
        <!-- <div class="footer-top">
            <div class="row">
                <div class="col-lg-3">
                    <a href="/" class="logo-footer" style="display: flex; ">
                        <img src="<?php echo e(url('logo/DFLogo1.jpg')); ?>" alt="logo-footer" width="100" height="39" />
                        <img src="<?php echo e(url('logo/DFLogo2.jpg')); ?>" alt="logo-footer" width="250" height="39" />
                    </a>
                </div>
            </div>
        </div> -->
        <!-- End of FooterTop -->
        <div class="footer-middle">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="widget">
                        <ul class="widget-body">
                            <li>
                                <label>Phone:</label>
                                <a href="#">80125 55950</a>
                            </li>
                        </ul>
                    </div>
                    <!-- End of Widget -->
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="widget ml-lg-4">
                        <ul class="widget-body">
                            <li><a href="<?php echo e(route('privacy.policy')); ?>">Privacy Policy</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="widget ml-lg-4">
                        <ul class="widget-body">
                            <li><a href="<?php echo e(route('refund.policy')); ?>">Refund Policy</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="widget ml-lg-4">
                        <ul class="widget-body">
                            <li><a href="<?php echo e(route('terms.conditions')); ?>">Terms & Conditions</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
       
        <!-- End of FooterBottom -->
    </div>
</footer><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/layouts/front/footer.blade.php ENDPATH**/ ?>