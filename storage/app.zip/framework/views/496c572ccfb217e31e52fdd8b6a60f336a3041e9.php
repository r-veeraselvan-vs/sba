<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Send Notification</h1>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
                <!-- general form elements -->
            <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Notification</h3>
                </div>
                
                        <!-- tags -->
                        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
                          <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
                          <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
                          <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
                          <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
                          <style type="text/css">
                              .dropdown-toggle{
                                  height: 40px;
                                  width: 100% !important;
                              }
                              .filter{
                                padding: 20px;
                              }
                          </style>
                          <form action="<?php echo e(route('notification.group.tag', [ 'type' => $notified_as ] )); ?>" method="post">
                              <?php echo csrf_field(); ?>
                            <div class="filter">
                                <label>Filter Users by Tags:</label><br/>
                                <select class="selectpicker" multiple data-live-search="true" name="selected_tags[]" onChange="this.form.submit()">
                                  <?php $__currentLoopData = $user_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($tag); ?>" <?php if(in_array($tag, $selected_tags)): ?> selected <?php endif; ?>><?php echo e($tag); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                          </form>
                          <script type="text/javascript">
                              $(document).ready(function() {
                                  $('select').selectpicker();
                              });
                          </script>
                        <!-- tags -->
                        

                <!-- form start -->
            <form action="<?php echo e(route('notification.save')); ?>" method="post" role="form" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                  <div class="card-body row">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger col-md-12">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="exampleInputname">Title</label>
                            <div class="">
                                <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputemail">Image</label>
                            <div class="">
                                <input type="file" name="image" class="form-control">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputPassword1">Description</label>
                            <div class="">
                                <textarea name="description" rows="4" class="form-control" required><?php echo e(old('description')); ?></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">

                        <div class="form-group">
                            <label for="exampleInputname">Notified as</label>
                            <div class="">
                                <input type="text" name="notified_as" value="<?php echo e(ucfirst($notified_as)); ?>" readonly class="form-control" >
                            </div>
                        </div>

                        <div class="form-group">
                     <?php if($type == 'group'): ?>
                        <label>Select Users</label>
                        <select class="form-control" id="users" height="200px" multiple="multiple" name="users[]" data-placeholder="Select User" style="width: 100%;">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" selected><?php echo e(ucfirst($user->name)); ?> (<?php echo e($user->email); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php elseif($type == 'single'): ?>
                        <label>User</label>
                        <select class="form-control" id="users"  multiple="multiple" name="users[]" data-placeholder="Select User" style="width: 100%;">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" selected><?php echo e(ucfirst($user->name)); ?> (<?php echo e($user->email); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <br />

                        <?php endif; ?>
                        </div>
                    </div>

                  </div>
                  <!-- /.card-body -->

                  <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Send</button>
                  </div>
                </form>
              </div>
              <!-- /.card -->
            </div>
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
 

<style>
#users{
    height:200px;
}
</style>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/notification/notification_create.blade.php ENDPATH**/ ?>