<?php $__env->startSection('content'); ?>

<main class="main mt-4">
    <div class="page-content mb-10">
        <div class="container">
            <div class="product product-single row mb-4">
                <div class="col-md-6">
                    <div class="product-gallery pg-vertical">
                        <div class="product-single-carousel owl-carousel owl-theme owl-nav-inner row cols-1" id="carousel">
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <figure class="product-image">
                                    <img src="<?php echo e($img->ImageUrl); ?>" data-zoom-image="<?php echo e($img->ImageUrl); ?>" alt="<?php echo e($product->name); ?>" width="800" height="900">
                                </figure>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- #caurosels -->
                        </div>
                        <div class="product-thumbs-wrap">
                            <div class="product-thumbs" id="thumbs">
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="product-thumb <?php if($i == 0): ?> active <?php endif; ?>">
                                        <img src="<?php echo e($img->ImageUrl); ?>" alt="<?php echo e($product->name); ?>" width="109" height="122">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- #thumbs -->
                            </div>
                            <button class="thumb-up disabled"><i class="fas fa-chevron-left"></i></button>
                            <button class="thumb-down disabled"><i class="fas fa-chevron-right"></i></button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="product-details">
                        
                        <?php if(Session::get('success')): ?> <p class="sxs"><?php echo e(Session::get('success')); ?></p> <?php endif; ?>
                        <style>
                        .sxs{
                            color: #212f21;
                            padding: 15px 95px;
                            background-color: #cfe470;
                            font-size: 14px;
                            font-weight: bold;
                            width: fit-content;
                            border-radius: 25px;
                        }
                        </style>

                        <h1 class="product-name"><?php echo e($product->name); ?></h1>
                        <?php
                            $heart = in_array($product->id, $wishlists);
                            $type = ($heart == true) ? 'false' : 'true';
                        ?> 
                        <a href="<?php echo e(route('wishlist.add', [ 'product_id' => $product->id, 'type' => $type ] )); ?>" class="" title="<?php if($heart): ?> Remove from wishlist <?php else: ?> Add to wishlist <?php endif; ?>"><i style="color:red; float:right" class=" <?php if($heart): ?> d-icon-heart-full <?php else: ?> d-icon-heart <?php endif; ?>"></i></a>
                        
                        <div class="product-meta">
                            CATEGORY: <a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $product->category->slug, 'sub_slug' => 'all' ])); ?>"><span class="product-sku"><?php echo e($product->category->category); ?></span></a> <br>
                            SUBCATEGORY: <a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $product->category->slug, 'sub_slug' => $product->subcategory->slug ])); ?>"><span class="product-sku"><?php echo e($product->subcategory->subcategory); ?></span></a>
                        </div>
                        
                        <div class="ratings-container">
                            <div class="ratings-full">
                                <?php
                                    $average_ratings = $product->average_ratings;
                                    $star = $average_ratings * 20;
                                ?>
                                <span class="ratings" style="width:<?php echo e($star); ?>%"></span>
                                <span class="tooltiptext tooltip-top"><?php echo e($average_ratings); ?></span>
                            </div>
                            <div>
                                <?php if($selected_price->inventory > 0): ?>
                                <span class="tip tip-green">In Stock</span>
                                <?php else: ?>
                                <span class="tip tip-red">Out of Stock</span>
                                <?php endif; ?>
                                <?php if($product->nonreturnable == 'No'): ?>
                                    &nbsp; <span class="tip tip-info" style="padding-left: 10px;">Non Returnable</span>
                                <?php endif; ?>
                            </div>
                            
                            <style>
                                .tip-green{
                                    background-color: #559c15;
                                }
                                .tip-red{
                                    background-color: #9c1515;
                                }
                                .tip-info{
                                    background-color: #132398;
                                }
                            </style>

                        </div>
                        <p class="product-short-desc"><?php echo $product->description; ?></p>

                        <?php if($product->matrix1): ?>
                            <div class="product-form product-variations product-color">
                                <label><?php echo e($product->matrix1); ?>:</label>
                                <div class="select-box">
                                    <select name="color" class="form-control" onChange="loadMatrix2();" id="matrix1" required>
                                        <option value="" selected="selected">Choose an Option</option>
                                        <?php $__currentLoopData = $matrix1_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matrix_one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($matrix_one); ?>" <?php if($matrix_one == $selected_price->matrix1): ?> selected <?php endif; ?>><?php echo e(ucfirst($matrix_one)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($product->matrix2): ?>
                            <div class="product-form product-variations product-size" onChange="selectMatrix2();" required>
                                <label><?php echo e($product->matrix2); ?>:</label>
                                <div class="product-form-group">
                                    <div class="select-box">
                                        <select name="size" class="form-control" id="matrix2">
                                        </select>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <script>
                            $(function() { onloadMatrix2(); });
                            
                            function onloadMatrix2(){
                                $('#matrix2').empty();
                                var matrix1 = "<?php echo e($selected_price->matrix1); ?>";                                
                                setImage(matrix1);
                                var matrix1Arr = <?php echo json_encode($matrix_ones, 15, 512) ?>;
                                var filteredArray = matrix1Arr.filter(x => x.matrix1 == matrix1);
                                var options = filteredArray.forEach( function(item, index){
                                    var sel = ('<?php echo e($selected_price->matrix2); ?>' == item.matrix2) ? 'selected' : '';
                                    $('#matrix2').append('<option value="'+item.id+'"'+sel+'>'+item.matrix2+'</option>');
                                });
                            }

                            function loadMatrix2(){
                                 var matrix1 = $('#matrix1').val();
                                var matrix1Arr = <?php echo json_encode($matrix_ones, 15, 512) ?>;
                                var filteredArray = matrix1Arr.filter(x => x.matrix1 == matrix1);
                                if(filteredArray){
                                    var url = '<?php echo e(url("product")); ?>'+'/'+(filteredArray[0].id)+'/'+'<?php echo e($product->slug); ?>';
                                    window.location = url;
                                }else{
                                    alert('Out of Stock');
                                }
                            }

                            function selectMatrix2(){
                                var matrix2 = $('#matrix2').val();
                                var matrix1Arr = <?php echo json_encode($matrix_ones, 15, 512) ?>;
                                var filteredArray = matrix1Arr.filter(x => x.id == matrix2);
                                if(filteredArray){
                                    var url = '<?php echo e(url("product")); ?>'+'/'+(filteredArray[0].id)+'/'+'<?php echo e($product->slug); ?>';
                                    window.location = url;
                                }else{
                                    alert('Out of Stock');
                                }
                            }

                            // Images Rendering
                            function setImage(matrix1){
                                if(matrix1 != ''){
                                    $('#carousel').empty();
                                    $('#thumbs').empty();
                                    var imagesArr = <?php echo json_encode($product->images, 15, 512) ?>;
                                    var filteredArray = imagesArr.filter(x => x.matrix1 == matrix1);
                                    console.log('Filtered Images of '+ matrix1, filteredArray)
                                    filteredArray.forEach( function(item, index){
                                        $('#carousel').append('<figure class="product-image">'+
                                            '<img src="'+item.ImageUrl+'" data-zoom-image="'+item.ImageUrl+'" alt="'+item.name+'" width="800" height="900">'+
                                        '</figure>');
                                        var act = (index == 0) ? 'active' : '';
                                        $('#thumbs').append('<div class="product-thumb '+act+'">'+
                                            '<img src="'+item.ImageUrl+'" alt="'+item.name+'" width="109"vheight="122">'+
                                        '</div>');
                                    });
                                }
                            }
                            // Images Rendering
                        </script>

                        
                        <!-- Offer Price Validation  -->
                        <?php if($selected_price->offer_percentage): ?>   
                            <?php
                                $date = strtotime(date("Y-m-d"));
                                $start_date = strtotime($selected_price->start_date);
                                $end_date = strtotime($selected_price->end_date);
                                if($date >= $start_date && $date <= $end_date){
                                    $price = $selected_price->offer_price;
                                    $strike_price = $selected_price->price;
                                    $show = true;
                                }else{
                                    $price = $selected_price->price;
                                    $strike_price = 0;
                                    $show = false;
                                }
                            ?>
                        <?php else: ?>
                            <?php
                                $price = $selected_price->price;
                                $strike_price = 0;
                                $show = false;
                            ?>
                        <?php endif; ?>
                        <!-- Offer Price Validation  -->

                        <hr class="product-divider">


                        <?php if($selected_price->inventory > 0): ?>
                        <div >
                            <div style="display: flex;">                                
                                <div class="product-price price px-2"> ₹ <?php echo e(number_format($price, 2)); ?> </div> 
                                <?php if($selected_price->offer_percentage && $show == true): ?> 
                                <del class="old-price" style="padding-left: 10px;"> ₹ <?php echo e(number_format($strike_price, 2)); ?> </del> 
                                <i class="offer-percentage" style="font-size: 16px; padding: 7px 10px; color: green;">(<?php echo e($selected_price->offer_percentage); ?>% OFF)</i>
                                <?php endif; ?>
                            </div>
                            <?php if($price && $selected_price->inventory > 0): ?>
                            <div> Exclusive of taxes </div>
                            <?php endif; ?>
                        </div>
                        <!-- Add Cart -->
                            <form action="<?php echo e(route('cart.add')); ?>" method="post" id="add-cart">
                                <!-- product_id :  -->
                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                    <!-- <br>
                                price id:  -->
                                    <input type="hidden" name="product_price_id" value="<?php echo e($selected_price->id); ?>">
                                    <!-- <br>
                                price :  -->
                                    <input type="hidden" name="price" value="<?php echo e($selected_price->price); ?>">
                                    <!-- <br>
                                offer_price :  -->
                                    <input type="hidden" name="offer_price" value="<?php echo e($show == true ? $selected_price->offer_price : 0); ?>">
                                    <input type="hidden" name="offer_expiry_date" value="<?php echo e($show == true ? $selected_price->end_date : ''); ?>">
                                    <!-- <br>
                                Weight :  -->
                                    <input type="hidden" name="weight" value="<?php echo e($selected_price->weight); ?>">
                                    <!-- <br>
                                quantity :  -->
                                    <input type="hidden" name="quantity" id="quantity" value="<?php echo e($cart ? $cart->quantity : 1); ?>">                            
                                    <!-- <br>
                                gst :  -->
                                    <input type="hidden" name="gst" value="<?php echo e($product->gst); ?>">                            
                            </form>
                            <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
                            <script>
                                $( document ).ready(function( $ ) {
                                    $('#plus').click(function(){
                                        var qty = $('#qty').val();
                                        $('#qty').val(parseInt(qty) + 1);
                                    });
                                    $('#minus').click(function(){
                                        var qty = $('#qty').val();
                                        if(qty>1){
                                            $('#qty').val(parseInt(qty) - 1);
                                        }
                                    });

                                    $('.qty').click(function(e){
                                        var qty = $('#qty').val();
                                        $('#quantity').val(qty);
                                    });
                                    $('#add-to-cart').click(function(e){
                                        e.preventDefault();
                                        var quantity = $('#qty').val();

                                        var inventory = '<?php echo e($selected_price->inventory); ?>';

                                        if(quantity > '0'){
                                            if(quantity <= parseInt(inventory)){
                                                $('#add-cart').submit();
                                                $('#error').html('');
                                            }else{
                                                $('#error').html('Out of stock, only '+inventory+' available.');
                                            }
                                        }else{
                                            $('#error').html('Please choose quantity');
                                        }
                                    });
                                });
                            </script>
                        <!-- Add Cart -->
                            <div class="product-form product-qty">
                                <label>QTY:</label>
                                <div class="product-form-group">
                                    <div class="input-group">
                                        <button id="minus" class="quantity-minus d-icon-minus qty"></button>
                                        <input id="qty" class="form-control" type="number" value="<?php echo e($cart ? $cart->quantity : 1); ?>" readonly>
                                        <button id="plus" class="quantity-plus d-icon-plus qty"></button>
                                    </div>
                                    <button class="btn-product btn-cart" type="submit" id="add-to-cart"><i class="d-icon-bag"></i>Add To Cart</button>
                                </div>
                            </div>
                        <?php else: ?>
                        <p style="color: red;">Out of stock, currently unavailable</p>
                        <?php endif; ?>

                    </div>
                </div>
            </div>

            
            <?php if(Session::has('success')): ?>
                <div style="color:green;"><?php echo e(Session::get('success')); ?></div>  <br>
            <?php endif; ?>
            
            <div class="tab tab-nav-simple product-tabs mb-4">
                <ul class="nav nav-tabs" role="tablist">
                    <?php if($product->features): ?>
                        <li class="nav-item <?php if(Session::get('tab') != 'review'): ?> active <?php endif; ?>">
                            <a class="nav-link" href="#feature">Benefits</a>
                        </li>
                    <?php endif; ?>
                    <?php if($product->specifications): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="#product-tab-additional">Nutritional Data</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link  <?php if(Session::get('tab') == 'review'): ?> active <?php endif; ?>" href="#product-tab-reviews">Reviews & Rating</a>
                    </li>
                </ul>
                <div class="tab-content">           
                    <!-- Features -->
                    <?php echo $__env->make('customer.front.common.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- Specifications -->
                    <?php echo $__env->make('customer.front.common.specifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    <!-- Reviews -->
                    <?php echo $__env->make('customer.front.common.reviews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                   
                </div>
            </div>
            
            <?php if($products): ?>
                <!-- Related Products -->
                <section>
                    <h2 class="title">Related Products</h2>
                    <div class="row">
                        <?php echo $__env->make('customer.front.common.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </section>
                <!-- Related Products -->
            <?php endif; ?>

        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front-demo2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/customer/front/product-detail.blade.php ENDPATH**/ ?>