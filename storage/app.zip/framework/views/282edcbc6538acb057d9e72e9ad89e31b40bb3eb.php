<?php $__env->startSection('content'); ?>
<main class="main">
    <div class="page-content">
        <section class="intro-section">

        <!-- Banners -->

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
                <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

                <div class="new-container">
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                        <ol class="carousel-indicators">
                            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li data-target="#myCarousel" data-slide-to="0" class=" <?php if($i == 0): ?> active <?php endif; ?>"></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ol>

                        <!-- Wrapper for slides -->
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item <?php if($i == 0): ?> active <?php endif; ?>">
                                    <img src="<?php echo e($banner->ImageUrl); ?>" alt="Image" style="width:100%;">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Left and right controls -->
                        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#myCarousel" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            <!-- Banners -->

            <!-- news -->
            <div class="service-list container-fluid news">
                <marquee width="100%" direction="left">
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a <?php if($n->url): ?> href="<?php echo e($n->url); ?>" target="_blank" <?php endif; ?>><i class="fa fa-check-circle"></i> <?php echo e($n->news); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </marquee>
            </div>
            <style>
                .news{
                    padding: 20px;
                }

                .news a{
                    padding: 0px 10px;
                }
            </style>
            <!-- news -->
            
            <div class="service-list container appear-animate">
                <div class="owl-carousel owl-theme row cols-lg-3 cols-sm-2 cols-1" data-owl-options="{
                                'items': 3,
                                'nav': false,
                                'dots': false,
                                'margin': 20,
                                'autoplay': true,
                                'autoplayTimeout': 5000,
                                'responsive': {
                                    '0': {
                                        'items': 1
                                    },
                                    '576': {
                                        'items': 2
                                    },
                                    '992': {
                                        'items': 3,
                                        'loop': false
                                    }
                                }
                            }">
                    <div class="icon-box icon-box-side icon-box1 appear-animate" data-animation-options="{
                                    'name': 'fadeInRightShorter',
                                    'delay': '.3s'
                                }">
                        <i class="icon-box-icon d-icon-truck"></i>
                        <div class="icon-box-content">
                            <h4 class="icon-box-title">Free Delivery in Madurai</h4>
                            <p>For Orders Above Rs. <?php echo e($settings->minimum_order_amount); ?></p>
                        </div>
                    </div>

                    <div class="icon-box icon-box-side icon-box2 appear-animate" data-animation-options="{
                                    'name': 'fadeInRightShorter',
                                    'delay': '.4s'
                                }">
                        <i class="icon-box-icon d-icon-service"></i>
                        <div class="icon-box-content">
                            <h4 class="icon-box-title">Customer Support 24/7</h4>
                            <p>80125 55950</p>
                        </div>
                    </div>

                    <div class="icon-box icon-box-side icon-box3 appear-animate" data-animation-options="{
                                    'name': 'fadeInRightShorter',
                                    'delay': '.5s'
                                }">
                        <i class="icon-box-icon d-icon-secure"></i>
                        <div class="icon-box-content">
                            <h4 class="icon-box-title">Cash on Delivery</h4>
                            <p>Simple payment method!</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
            <div class="container home-suc-msg">
                <?php if(Session::get('success')): ?> <div class="sxs"><?php echo e(Session::get('success')); ?></div> <?php endif; ?>
                <style>
                .sxs{
                    color: #212f21;
                    padding: 15px 95px;
                    background-color: #cfe470;
                    font-size: 14px;
                    font-weight: bold;
                    width: fit-content;
                    border-radius: 25px;
                }
                .home-suc-msg {
                    text-align: -webkit-center;
                }
                </style>
            </div>

        <section class="grey-section pt-10 pb-10 appear-animate" data-animation-options="{
                    'delay': '.3s'
                }">
            <div class="container pt-3">
                <h2 class="title">Browse Our Categories</h2>
                
                <!-- Caraosul new -->
                <section class="product-wrapper container appear-animate mt-10 pt-3 pb-8" data-animation-options="{ 'delay': '.3s' }">
                    <div class="owl-carousel owl-theme row owl-nav-full cols-2 cols-md-3 cols-lg-4" data-owl-options="{ 'items': 5, 'nav': false, 'loop': false, 'dots': true, 'margin': 20, 'responsive': { '0': { 'items': 2 }, '768': { 'items': 3 }, '992': { 'items': 4, 'dots': false, 'nav': true } } }">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- <div class="col-md-3 col-6 mb-4"> -->
                                <div class="category category-default category-default-1 category-absolute overlay-zoom">
                                    <a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $category->slug, 'sub_slug' => 'all' ])); ?>">
                                        <figure class="category-media">
                                            <img src="<?php echo e($category->HomeImageUrl); ?>" alt="category" width="280"
                                                height="280" />
                                        </figure>
                                    </a>
                                    <div class="category-content">
                                        <h4 class="category-name"><a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $category->slug, 'sub_slug' => 'all' ])); ?>"><?php echo e($category->category); ?></a></h4>
                                    </div>
                                </div>
                            <!-- </div> -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
                <style>
                    .owl-nav .owl-next, .owl-nav .owl-prev {
                        color: #fff !important;
                        background-color: rgb(34 102 187) !important;
                    }

                </style>
                <!-- Caraosul new -->

                <!-- <div class="row">

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-6 mb-4">
                            <div class="category category-default category-default-1 category-absolute overlay-zoom">
                                <a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $category->slug, 'sub_slug' => 'all' ])); ?>">
                                    <figure class="category-media">
                                        <img src="<?php echo e($category->HomeImageUrl); ?>" alt="category" width="280"
                                            height="280" />
                                    </figure>
                                </a>
                                <div class="category-content">
                                    <h4 class="category-name"><a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $category->slug, 'sub_slug' => 'all' ])); ?>"><?php echo e($category->category); ?></a></h4>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div> -->
            </div>
        </section>
        
        <section class="product-wrapper container appear-animate mt-10 pt-3 pb-8" data-animation-options="{ 'delay': '.3s' }">  
            <h2 class="title"><?php echo e($one_title); ?></h2>
            <div class="owl-carousel owl-theme row owl-nav-full cols-2 cols-md-3 cols-lg-4" data-owl-options="{ 'items': 5, 'nav': false, 'loop': false, 'dots': true, 'margin': 20, 'responsive': { '0': { 'items': 2 }, '768': { 'items': 3 }, '992': { 'items': 4, 'dots': false, 'nav': true } } }">
                <?php ($products = $ones); ?>
                <?php echo $__env->make('customer.front.common.product-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>

        <section class="product-wrapper container appear-animate mt-10 pt-3 pb-8" data-animation-options="{ 'delay': '.3s' }">  
            <h2 class="title"><?php echo e($two_title); ?></h2>
            <div class="owl-carousel owl-theme row owl-nav-full cols-2 cols-md-3 cols-lg-4" data-owl-options="{ 'items': 5, 'nav': false, 'loop': false, 'dots': true, 'margin': 20, 'responsive': { '0': { 'items': 2 }, '768': { 'items': 3 }, '992': { 'items': 4, 'dots': false, 'nav': true } } }">
                <?php ($products = $twos); ?>
                <?php echo $__env->make('customer.front.common.product-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>
        
        <section class="product-wrapper container appear-animate mt-10 pt-3 pb-8" data-animation-options="{ 'delay': '.3s' }">  
            <h2 class="title"><?php echo e($three_title); ?></h2>
            <div class="owl-carousel owl-theme row owl-nav-full cols-2 cols-md-3 cols-lg-4" data-owl-options="{ 'items': 5, 'nav': false, 'loop': false, 'dots': true, 'margin': 20, 'responsive': { '0': { 'items': 2 }, '768': { 'items': 3 }, '992': { 'items': 4, 'dots': false, 'nav': true } } }">
                <?php ($products = $threes); ?>
                <?php echo $__env->make('customer.front.common.product-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>
        
        <section class="product-wrapper container appear-animate mt-10 pt-3 pb-8" data-animation-options="{ 'delay': '.3s' }">  
            <h2 class="title"><?php echo e($four_title); ?></h2>
            <div class="owl-carousel owl-theme row owl-nav-full cols-2 cols-md-3 cols-lg-4" data-owl-options="{ 'items': 5, 'nav': false, 'loop': false, 'dots': true, 'margin': 20, 'responsive': { '0': { 'items': 2 }, '768': { 'items': 3 }, '992': { 'items': 4, 'dots': false, 'nav': true } } }">
                <?php ($products = $fours); ?>
                <?php echo $__env->make('customer.front.common.product-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>

    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/customer/front/home.blade.php ENDPATH**/ ?>