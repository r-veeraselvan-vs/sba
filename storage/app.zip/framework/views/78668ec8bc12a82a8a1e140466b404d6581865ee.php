<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Order Summary</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- /.content-header -->

    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="tab-content">

                    <!-- main Service -->
                    <div class="tab-pane active">
                        <form action="" method="post" class="filter-custom">
                            <label for="">Start Date: </label>
                            <input type="date" name="start_date" id="" value="<?php echo e($start_date); ?>">
                            <label for=""> End Date: </label>
                            <input type="date" name="end_date" id="" value="<?php echo e($end_date); ?>">
                            <label for=""> Delivery Status: </label>
                            <select name="delivery_status">
                                <option value=""> -- All -- </option>
                                <option value="Order Received" <?php if($delivery_status == "Order Received"): ?> selected <?php endif; ?>>Order Received</option>
                                <option value="Packed" <?php if($delivery_status == "Packed"): ?> selected <?php endif; ?>>Packed</option>
                                <option value="Out for Delivery" <?php if($delivery_status == "Out for Delivery"): ?> selected <?php endif; ?>>Out for Delivery</option>
                                <option value="Delivered" <?php if($delivery_status == "Delivered"): ?> selected <?php endif; ?>>Delivered</option>
                            </select>
                            <input type="submit" value="Filter">
                        </form>
                        <style>
                            .filter-custom{
                                padding: 20px;
                                background: #ececec;
                                margin-bottom: 10px;
                            }
                        </style>
                        <table id="export" class="table">
                            <thead>
                                <tr>
                                    <th>Sl No</th>
                                    <th>Category</th>
                                    <th>Product</th>
                                    <th>Metrics</th>
                                    <th>Varient</th>
                                    <th>Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><?php echo e(@$order_detail->product->category_id); ?> . <?php echo e(@$order_detail->product->category->category); ?></td>
                                    <td>
                                        <img width="50px" src="<?php echo e(@$order_detail->product->ThumbnailUrl); ?>" alt="">
                                        <b><?php echo e($order_detail->product->name); ?></b>
                                    </td>
                                    <td>
                                        <b><?php if(@$order_detail->product->matrix1 != ''): ?><?php echo e(@$order_detail->product->matrix1); ?><?php endif; ?></b><b><?php if(@$order_detail->product->matrix2 != ''): ?>, <?php echo e(@$order_detail->product->matrix2); ?> <?php endif; ?></b>
                                    </td>
                                    <td>
                                        <?php if(@$order_detail->product->matrix1 != ''): ?> <?php echo e(@$order_detail->product_price->matrix1); ?><?php endif; ?> <?php if(@$order_detail->product->matrix2 != ''): ?>,  <?php echo e(@$order_detail->product_price->matrix2); ?> <?php endif; ?>
                                    </td>
                                    <td><?php echo e(@$order_detail->quantity); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
        </div>
    </div>

</div>

<script>
  $(document).ready(function() {
        var date = "<?php echo e(date('d-m-Y')); ?>";
        $('#export').DataTable( {
            dom: 'Blfrtip',
            buttons: [ { extend: 'excel', title: 'Order_Summary_'+date } ],
            responsive: true,
            autoWidth: false,
            order: [[ 1, "asc" ]]
        } );
        $('.dt-button').html('<i class="fa fa-download" aria-hidden="true"></i> Export to Excel');
    } );
</script>

<style>
 .dt-button{
    color: #fff;
    background-color: #1050AF;
    border-color: #1050AF;
    box-shadow: none;
    display: inline-block;
    font-weight: 400;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    border: 1px solid transparent;
    padding: .375rem .75rem;
    font-size: 1rem;
    line-height: 1.5;
    border-radius: .25rem;
    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
 }
 .dt-button:hover{
    color: #fff;
    background-color: #0069d9;
    border-color: #1050AF;
 }

 </style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/order/order_summary_list.blade.php ENDPATH**/ ?>