<?php $__env->startSection('content'); ?>

<style>
      /*
          Use the DejaVu Sans font for displaying and embedding in the PDF file.
          The standard PDF fonts do not support Unicode characters.
      */
      div {
        font-family: "DejaVu Sans", "Arial", sans-serif;
        font-size: 12px;
      }

      /*
        The example loads the DejaVu Sans from the Kendo UI CDN.
        Other fonts have to be hosted from your application.
        The official site of the Deja Vu Fonts project is
        https://dejavu-fonts.github.io/.
      */
      @font-face {
        font-family: "DejaVu Sans";
        src: url("https://kendo.cdn.telerik.com/2021.2.511/styles/fonts/DejaVu/DejaVuSans.ttf") format("truetype");
      }

      @font-face {
        font-family: "DejaVu Sans";
        font-weight: bold;
        src: url("https://kendo.cdn.telerik.com/2021.2.511/styles/fonts/DejaVu/DejaVuSans-Bold.ttf") format("truetype");
      }

      @font-face {
        font-family: "DejaVu Sans";
        font-style: italic;
        src: url("https://kendo.cdn.telerik.com/2021.2.511/styles/fonts/DejaVu/DejaVuSans-Oblique.ttf") format("truetype");
      }

      @font-face {
        font-family: "DejaVu Sans";
        font-weight: bold;
        font-style: italic;
        src: url("https://kendo.cdn.telerik.com/2021.2.511/styles/fonts/DejaVu/DejaVuSans-Oblique.ttf") format("truetype");
      }

      .k-widget {
  font-family: "DejaVu Sans";
}
    </style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="http://kendo.cdn.telerik.com/2017.2.621/js/kendo.all.min.js"></script>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <?php if($type == 'edit'): ?>
                    <h1>Edit Order</h1>
                    <?php else: ?>
                    <h1>View Order</h1>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="<?php if($type == 'edit'): ?> col-md-8 <?php else: ?> col-md-12 <?php endif; ?>">
                    <div class="card card-primary">
                        <div class="card-body">

                            <!-- <a onclick="ExportPdf()" class="btn btn-sm btn-primary" style="color:#fff;"> Download
                                Invoice</a> -->
                            <a href="<?php echo e(route('order.download.html', [ 'id' => $order->id ])); ?>" target="_blank" class="btn btn-sm btn-primary" style="color:#fff;"> Download
                                Invoice as HTML</a>
                            <table id="bill-canvas" class="table">
                                <thead>
                                    <tr>
                                        <th colspan="7" style="text-align:center;">
                                            <h4>Madurai Kadai</h4>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th colspan="7" style="text-align:center;">Invoice</th>
                                    </tr>
                                    <tr>
                                        <th>Sl No</th>
                                        <!-- <th>Image</th> -->
                                        <th colspan="3">Product</th>
                                        <th>Price</th>
                                        <th>Qty</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i+1); ?></td>
                                        <td colspan="3"><?php echo e($order_detail->product->name); ?>

                                            <br>
                                            <?php if(@$order_detail->product->matrix1 != ''): ?><b><?php echo e(@$order_detail->product->matrix1); ?>:</b> <?php echo e(@$order_detail->product_price->matrix1); ?> <?php endif; ?> 
                                            <?php if(@$order_detail->product->matrix2 != ''): ?><b><?php echo e(@$order_detail->product->matrix2); ?>:</b> <?php echo e(@$order_detail->product_price->matrix2); ?> <?php endif; ?>
                                        
                                        </td>
                                        <td>
                                            <!-- <small>(<?php echo e($order_detail->weight); ?>x<?php echo e($order_detail->quantity); ?>) <?php echo e($order_detail->total_weight); ?> grams</small> -->
                                            <?php echo e(number_format($order_detail->price,2)); ?>

                                        </td>
                                        <td><?php echo e($order_detail->quantity); ?></td>
                                        <td><?php echo e(number_format($order_detail->amount,2)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th colspan="2">Payment Status</th>
                                        <td colspan="2"><?php echo e($order->status); ?></td>
                                        <td></td>
                                        <td><b>Sub Total:</b></td>
                                        <td><?php echo e(number_format($order->sub_total,2)); ?></td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Order Date</th>
                                        <td colspan="2"><?php echo e($order->order_time ?  date('d/m/Y', strtotime($order->order_time)) : $order->created_at->toDateString()); ?></td>
                                        <td></td>
                                        <td><b>Shipping:</b></td>
                                        <td><?php echo e(number_format($order->shipping_charge,2)); ?></td>
                                    </tr>
                                    <tr>
                                        <th colspan="2"></th>
                                        <td></td>
                                        <td colspan="2">                                        
                                            <p>
                                                <?php if(substr($order->address->postcode, 0, 1) == 6): ?>
                                                    <b>CGST:</b> <?php echo e(number_format($order->order_details->sum('cgst_amount'),2)); ?> &nbsp; &nbsp;
                                                    <b>SGST:</b> <?php echo e(number_format($order->order_details->sum('sgst_amount'),2)); ?>

                                                <?php else: ?>
                                                    <b>IGST:</b> <?php echo e(number_format($order->order_details->sum('igst_amount'),2)); ?>

                                                <?php endif; ?>
                                            </p>                                        
                                        </td>
                                        <td><b>Tax:</b></td>
                                        <td><?php echo e(number_format($order->tax,2)); ?></td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Delivery Status</th>
                                        <td colspan="2"><?php echo e($order->delivery_status); ?></td>
                                        <td > </td>
                                        <td><b>Total:</b></td>
                                        <td><?php echo e(number_format($order->net_amount,2)); ?></td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Customer Details</th>
                                        <td colspan="2">
                                            <span>
                                                <?php echo e(ucfirst($order->user->name)); ?>

                                            </span><br>
                                            <span>
                                                <?php echo e($order->user->email); ?>

                                            </span><br>
                                            <span>
                                                <?php echo e($order->user->mobile); ?>

                                            </span>
                                        </td>
                                        <td colspan="3">
                                            <b>Delivery Date: </b> <?php echo e($order->delivery_date); ?>

                                            <br> <b>Delivery Slot: </b> 
                                                <?php if(@$order->delivery_slot->default == 'Yes'): ?> 
                                                    Default Slot 
                                                <?php else: ?>
                                                    <?php echo e(@$order->delivery_slot->start); ?> - <?php echo e(@$order->delivery_slot->end); ?>

                                                <?php endif; ?>
                                            <br> <b>Payment Mode: </b> <?php echo e($order->payment_mode); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <th colspan="2">Customer Address</th>
                                        <td colspan="2">
                                            <span>
                                                <?php echo e($order->address->address); ?>

                                            </span><br>
                                            <span> <?php echo e($order->address->city); ?>, <?php echo e($order->address->country); ?> - <?php echo e($order->address->postcode); ?></span>
                                        </td>
                                        <td colspan="3"></td>
                                    </tr>

                                    <?php if(Session::has('success')): ?>
                                    <tr class="alert alert-success">
                                        <td colspan="7"><?php echo e(Session::get('success')); ?></td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php if($type == 'edit'): ?>
                <div class="col-md-4">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Delivery Update</h3>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('order.update', [ 'id' => $order->id ])); ?>" method="post">
                                <table id="" class="table">
                                    <tbody>
                                        <tr>
                                            <th>Status:</th>
                                            <td>
                                                <select name="delivery_status" class="form-control">
                                                    <option <?php if($order->delivery_status == 'Order Received'): ?> selected
                                                        <?php endif; ?> value="Order Received">Order Received</option>
                                                    <option <?php if($order->delivery_status == 'Packed'): ?> selected <?php endif; ?>
                                                        value="Packed">Packed</option>
                                                    <option <?php if($order->delivery_status == 'Out for Delivery'): ?> selected <?php endif; ?>
                                                        value="Out for Delivery">Out for Delivery</option>
                                                    <option <?php if($order->delivery_status == 'Delivered'): ?> selected <?php endif; ?>
                                                        value="Delivered">Delivered</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Assign Rider:</th>
                                            <td>
                                                <select name="rider_id" class="form-control">
                                                    <option value="">-</option>
                                                    <?php $__currentLoopData = $riders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if($order->rider_id == $rider->id): ?> selected <?php endif; ?>
                                                        value="<?php echo e($rider->id); ?>"><?php echo e($rider->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <button class="btn btn-primary">Update</button>
                                            </td>
                                            <th></th>
                                        </tr>
                                    </tbody>
                                </table>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
</div>

<style>
.alert {
    position: relative;
    padding: .75rem 1.25rem;
    margin-bottom: 1rem;
    border: 1px solid transparent;
    border-radius: .25rem;
}

.alert-success {
    color: #155724;
    background-color: #d4edda;
    border-color: #c3e6cb;
}
</style>

<script>


kendo.pdf.defineFont({
        "DejaVu Sans":
             "https://cdn.kendostatic.com/2021.2.511/styles/fonts/DejaVu/DejaVuSans.ttf",

        "DejaVu Sans|Bold":
            "https://cdn.kendostatic.com/2021.2.511/styles/fonts/DejaVu/DejaVuSans-Bold.ttf",

        "DejaVu Sans|Bold|Italic":
             "https://cdn.kendostatic.com/2021.2.511/styles/fonts/DejaVu/DejaVuSans-Oblique.ttf",

        "DejaVu Sans|Italic":
             "https://cdn.kendostatic.com/2021.2.511/styles/fonts/DejaVu/DejaVuSans-Oblique.ttf"
    });

function ExportPdf() {
    kendo.drawing
        .drawDOM("#bill-canvas", {
            forcePageBreak: ".page-break",
            paperSize: "A4",
            margin: {
                top: "1cm",
                bottom: "1cm"
            },
            scale: 0.8,
            height: 500,
            template: $("#page-template").html(),
            keepTogether: ".prevent-split"
        })
        .then(function(group) {
            kendo.drawing.pdf.saveAs(group, "Invoice_<?php echo e($order->id); ?>_<?php echo e($order->created_at->toDateString()); ?>.pdf")
        });

}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/order/order_details.blade.php ENDPATH**/ ?>