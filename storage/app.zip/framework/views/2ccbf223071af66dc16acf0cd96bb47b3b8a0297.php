<div class="tab-pane" id="product-tab-additional">
    <ul class="list-none">
        <?php $__currentLoopData = $product->specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><label><?php echo e($spec->name); ?>:</label>
            <p><?php echo e($spec->details); ?></p>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/customer/front/common/specifications.blade.php ENDPATH**/ ?>