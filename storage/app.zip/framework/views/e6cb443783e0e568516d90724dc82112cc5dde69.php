<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Orders Received</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- /.content-header -->

    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="tab-content">

                    <!-- main Service -->
                    <div class="tab-pane active">
                        <table id="example1" class="table">
                            <thead>
                                <tr>
                                    <th>Sl No</th>
                                    <th>Order No</th>
                                    <th>Date</th>
                                    <th>Customer Details</th>
                                    <th>Items</th>
                                    <th>Price</th>
                                    <th>Delivery Date</th>
                                    <th>Slot</th>
                                    <th>Payment Mode</th>
                                    <th>Change</th>
                                    <th>Status</th>
                                    <th>Delivery Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i+1); ?></td>
                                    <td><?php echo e($order->id); ?></td>
                                    <td><?php echo e($order->order_time ?  date('d/m/Y', strtotime($order->order_time)) : $order->created_at->toDateString()); ?></td>
                                    <td>
                                        <p><i class="fa fa-user"></i>&nbsp; <?php echo e(ucfirst(@$order->user->name)); ?></p>
                                        <p> <i class="fa fa-phone"></i>&nbsp; <?php echo e($order->user->mobile); ?></p>
                                    </td>
                                  
                                    <td><?php echo e($order->items); ?></td>
                                    <td><?php echo e($order->net_amount); ?></td>
                                    <td><?php echo e(@$order->delivery_date); ?></td>
                                    <td><?php echo e(@$order->delivery_slot->start); ?> - <?php echo e(@$order->delivery_slot->end); ?></td>
                                    <td><?php echo e($order->payment_mode); ?></td>
                                    <td><?php echo e(@$order->change_required); ?></td>
                                    <td><?php echo e($order->status); ?></td>
                                    <td><?php echo e($order->delivery_status); ?></td>
                                    <td>
                                        <a
                                            href="<?php echo e(route('order.detail', [ 'id' => $order->id , 'type' => 'view' ])); ?>"><span
                                                class="badge bg-info"><i class="fas fa-eye"></i></span></a>
                                        <a
                                            href="<?php echo e(route('order.detail', [ 'id' => $order->id , 'type' => 'edit' ])); ?>"><span
                                                class="badge bg-danger"><i class="fas fa-edit"></i></span></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/order/order_list.blade.php ENDPATH**/ ?>