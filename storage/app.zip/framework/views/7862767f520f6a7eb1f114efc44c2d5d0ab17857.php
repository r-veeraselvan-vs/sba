<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Customer List</h1>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
          <div class="row">
             <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <div class="col-sm-12">
                      <a href="<?php echo e(route('notification.group', [ 'type' => 'customer' ] )); ?>" class="btn btn-primary" style="float: right;"><i class="fas fa-bell"></i> Group Notification</a>
                    </div>
                  </div>
                  <div class="card-body">
                    <table id="example1" class="table">
                      <thead>
                      <tr>
                        <th>Sl No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Shipping Excluded</th>
                        <th>Joined on</th>
                        <th>Action</th>
                      </tr>
                      </thead>
                      <tbody>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i+1); ?></td>
                        <td>
                            <a><?php echo e($customer->name); ?></a>
                        </td>
                        <td><?php echo e($customer->email); ?></td>
                        <td><?php echo e($customer->mobile); ?></td>
                        <td><?php echo e(@$customer->customer->shipping_excluded ? @$customer->customer->shipping_excluded : 'No'); ?></td>
                        <td><?php echo e($customer->created_at->format('d-m-Y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('customer.view', [ 'customer_id' => $customer->id ] )); ?>"><span class="badge bg-success"><i class="fas fa-eye"></i></span></a>
                            <a href="<?php echo e(route('customer.edit', [ 'user_id' => $customer->id ] )); ?>"><span class="badge bg-danger"><i class="fas fa-edit"></i></span></a>
                            <a href="<?php echo e(route('notification.customer', [ 'id' => $customer->id ] )); ?>"><span class="badge bg-info"><i class="fas fa-bell"></i></span></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </tbody>
                    </table>
                  </div>
                  <!-- /.card-body -->
                </div>
                <!-- /.card -->
              </div>
              <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>
    <!-- /.content -->
  </div>

  
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/customer/customer_list.blade.php ENDPATH**/ ?>