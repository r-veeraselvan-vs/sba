<?php $__env->startSection('content'); ?>

<main class="main">
            <div class="page-header" style="background-image: url(images/page-header.jpg)">
                <h1 class="page-title">Terms & Conditions</h1>
            </div>
            <div class="page-content mt-10 pt-7">
                <section class="about-section">
                    <div class="container">
                        <div class="tab-pane active in" id="product-tab-description">
                            <h6>Website, Mobile App and Service Terms and Conditions - General</h6>
                            <p>The Direct Farms website ("Website")and related services (together with the Website and related services, the "Service") are operated by Direct Farms. ("Direct Farms", "us" or "we"). Access and use of the Service is subject to the following Terms and Conditions of Service ("Terms and Conditions"). By accessing or using any part of the Service, you represent that you have read, understood, and agree to be bound by these Terms and Conditions including any future modifications.</p>
                            <p>Direct Farms may amend, update or change these Terms and Conditions. If we do this, we will post a notice that we have made changes to these Terms and Conditions on the Website for at least 7 days after the changes are posted and will indicate at the bottom of the Terms and Conditions the date these terms were last revised. Any revisions to these Terms and Conditions will become effective the earlier of</p>
                            <ul class="list-type ml-2 font-secondary">
                                <li>(i) the end of such 7-day period or</li>
                                <li>(ii) the first time you access or use the Service after such changes. If you do not agree to abide by these Terms and Conditions, you are not authorized to use, access or participate in the Service.</li>
                            </ul>
                            
                            <h6>Description of Website and Service</h6>
                            <p>The Service allows users to

                            (i) purchase various groceries, fruits, vegetables and other edible products offered by Direct Farms. Users interested in purchasing are presented with different types of products. Direct Farms may, in its sole discretion and at any time, update, change, suspend, make improvements to or discontinue any aspect of the Service, temporarily or permanently.</p>
                            
                            <h6>Registration</h6>
                            <p>In connection with registering for and using the Service, you agree</p>
                            <ul class="list-type ml-2 font-secondary">
                                <li>(i) to provide accurate, current and complete information about you and/or your organization as requested by Direct Farms;</li>
                                <li>(ii) to maintain the confidentiality of your password and other information related to the security of your account;</li>
                                <li>(iii) to maintain and promptly update any registration information you provide to Direct Farms while registering or during your usage of Direct Farms's services, to keep such information accurate, current and complete;</li>
                                <li>(iv) to be fully responsible for all use of your account and for any actions that take place through your account;</li>
                                <li>(v) You consent to be contacted by us via phone calls and/or SMS notifications, in case of any order or shipment or delivery related updates</li>
                            </ul>
                            
                            <h6>Your Representations and Warranties</h6>
                            <p>You represent and warrant to Direct Farms that your access and use of the Service will be in accordance with these Terms and Conditions and with all applicable laws, rules and regulations of Constitution of India and any other relevant jurisdiction, including those regarding online conduct or acceptable content, and those regarding the transmission of data or information exported from India and/or the jurisdiction in which you reside. You further represent and warrant that you have created or own any material you submit to Direct Farms and that you have the right to grant us a license to use that material.</p>
                            
                            <h6>Inappropriate Use</h6>
                            <p>You will not upload, display or otherwise provide on or through the Service any content that:</p>
                            <ul class="list-type ml-2 font-secondary">
                                <li>(i) is libelous, defamatory, abusive, threatening, harassing, hateful, offensive or otherwise violates any law or infringes upon the right of any third party (including copyright, trademark, privacy, publicity or other personal or proprietary rights); or</li>
                                <li>(ii) in Direct Farms's sole judgment, is objectionable or which restricts or inhibits any other person from using the Service or which may expose Direct Farms or its users to any harm or liability of any kind.</li>
                            </ul>

                            <h6>Indemnification of Direct Farms</h6>
                            <p>You agree to defend, indemnify and hold harmless Direct Farms and its promoters, officers, employees, contractors, agents, suppliers, licensors, successors and assigns, from and against any and all losses, claims, causes of action, obligations, liabilities and damages whatsoever, including attorneys' fees, arising out of or relating to your access or use of the Service, any false representation made to us (as part of these Terms and Conditions or otherwise), your breach of any of these Terms and Conditions,or any claim that any service we provide to you is inaccurate, inappropriate or defective in any way whatsoever.</p>

                            <h6>No Representations or Warranties</h6>
                            <p>The service, including all images, audio files and other content therein, and any other information, property and rights granted or provided to you by Direct Farms are provided to you on an "as is" basis. Direct Farms and its suppliers make no representations or warranties of any kind with respect to the service, either express or implied, and all such representations and warranties, including warranties of merchantability, fitness for a particular purpose or non-infringement, are expressly disclaimed. Without limiting the generality of the foregoing, Direct Farms does not make any representation or warranty of any kind relating to accuracy, service availability, completeness, informational content, error-free operation, results to be obtained from use, or non-infringement. Access and use of the service may be unavailable during periods of peak demand, system upgrades, malfunctions or scheduled or unscheduled maintenance or for other reasons. Some jurisdictions do not allow the exclusion of implied warranties, so the above exclusion may not apply to you.</p>

                            <h6>Limitation on types of Damages/Limitation of Liability</h6>
                            <p>In no event will Direct Farms be liable to you or any third party claiming through you (whether based in contract, tort, strict liability or other theory) for indirect, incidental, special, consequential or exemplary damages arising out of or relating to the access or use of, or the inability to access or use, the service or any portion thereof, including but not limited to the loss of use of the service, inaccurate results, loss of profits, business interruption, or damages stemming from loss or corruption of data or data being rendered inaccurate, the cost of recovering any data, the cost of substitute services or claims by third parties for any damage to computers, software, modems, telephones or other property, even if Direct Farms has been advised of the possibility of such damages. Direct Farms's liability to you or any third party claiming through you for any cause whatsoever, and regardless of the form of the action, is limited to the amount paid, if any, by you to Direct Farms for the service in the 12 months prior to the initial action giving rise to liability. This is an aggregate limit. The existence of more than one claim hereunder will not increase this limit.</p>

                            <h6>Termination</h6>
                            <p>Direct Farms may terminate your access and use of the Service immediately at any time, for any reason, and at such time you will have no further right to use the Service. You may terminate your Direct Farms account at any time by following the instructions available through the Service. The provisions of these Terms and Conditions relating to the protection and enforcement of Direct Farms's proprietary rights, your representations and warranties, disclaimer of representations and warranties, release and indemnities, limitations of liability and types of damages, ownership of data and information, governing law and venue, and miscellaneous provisions shall survive any such termination.</p>

                            <h6>Proprietary Rights in Service Content and Activity Data</h6>
                            <p>All content available through the Service, including designs, text, graphics, images, information, software, audio and other files, and their selection and arrangement (the "Service Content"), are the proprietary property of Direct Farms or its licensors. No Service Content may be modified, copied, distributed, framed, reproduced, republished, downloaded, scraped, displayed, posted, transmitted, or sold in any form or by any means, in whole or in part, other than as expressly permitted in these Terms and Conditions. You may not use any data mining, robots, scraping or similar data gathering or extraction methods to obtain Service Content. As between you and Direct Farms, all data and information generated from your access and use of the educational activities made available on or through the Service, including translated content generated by you (collectively, the "Activity Data"), shall be exclusively owned by Direct Farms, and you shall not have any right to use such Activity Data except as expressly authorized by these Terms and Conditions. Activity Data will not include material you submit for translation or any resulting translation. By using the Service, you hereby assign to Direct Farms any and all rights, title and interest, including any intellectual property rights or proprietary rights, in the Activity Data. All rights of Direct Farms or its licensors that are not expressly granted in these Terms and Conditions are reserved to Direct Farms and its licensors.</p>

                            <h6>Privacy</h6>
                            <p>Use of the Service is also governed by our Privacy Policy, a copy of which is located at <a href="https://www.directfarms.biz/privacy-policy">https://www.directfarms.biz/privacy-policy</a> By using the Service, you consent to the terms of the Privacy Policy.</p>

                            <h6>Refund Policy</h6>
                            <p>The refund is applicable for some of our products subject to the conditions laid down in our refund policy and the copy of the same is located at <a href="https://www.directfarms.biz/refund-policy">https://www.directfarms.biz/refund-policy</a> By using the Service, you consent that you have read the Refund Policy and agree to it.</p>

                            <h6>Notice for Claims of Copyright Violations and Agent for Notice</h6>
                            <p>If you are a copyright owner and have a good faith belief that any material available through the service infringes upon your copyrights, you may submit a copyright infringement notification to Direct Farms pursuant to the Digital Millennium Copyright Act by providing us with the following information in writing:</p>
                            <ul class="list-type ml-2 font-secondary">
                                <li>an electronic or physical signature of the copyright owner or the person authorized to act on behalf of the owner of the copyright interest;</li>
                                <li>a description of the copyrighted work that you claim has been infringed;</li>
                                <li>a description of where the material that you claim is infringing is located on the Service, with enough detail that we may find it on the Service;</li>
                                <li>your address, telephone number, and email address;</li>
                                <li>a statement by you that you have a good faith belief that the disputed use is not authorized by the copyright owner, its agent, or the law; and</li>
                                <li>a statement by you, made under penalty of perjury, that the above information in your notice is accurate and that you are the copyright owner or are authorized to act on the copyright owner's behalf.</li>
                            </ul>
                            <p>Please consult your legal counsel for further details or see Section 51 of The Copyright Act, 1957.</p>
                            <p>Direct Farms's Agent for Notice of claims of copyright infringement can be reached by email at admin@directfarms.biz</p>

                            <h6>Governing Law and Arbitration</h6>
                            <p>These Terms and Conditions, its subject matter and Direct Farms's and your respective rights under these Terms and Conditions shall be governed by the laws of India and you agree that the courts of Chennai will have exclusive jurisdiction over any dispute (contractual or non-contractual) concerning these terms.</p>

                            <h6>Miscellaneous</h6>
                            <p>These Terms and Conditions constitute the entire agreement between Direct Farms and you concerning the subject matter hereof. In the event that any of the Terms and Conditions are held by a court or other tribunal of competent jurisdiction to be unenforceable, such provisions shall be limited or eliminated to the minimum extent necessary so that these Terms and Conditions shall otherwise remain in full force and effect. A waiver by Direct Farms or you of any provision of these Terms and Conditions or any breach thereof, in any one instance, will not waive such term or condition or any subsequent breach thereof. Direct Farms may assign its rights or obligations under these Terms and Conditions without condition. These Terms and Conditions will be binding upon and will inure to the benefit of Direct Farms and you, and Direct Farms's and your respective successors and permitted assigns.</p>

                            <h6>Last Updated On: 27/05/2021</h6>
                        </div>
                    </div>
                </section>
                <!-- End About Section-->

            </div>
        </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/customer/front/terms-conditions.blade.php ENDPATH**/ ?>