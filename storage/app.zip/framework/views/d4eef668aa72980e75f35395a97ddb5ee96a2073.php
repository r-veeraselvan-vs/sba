<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Update Details</h1>
          </div>
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
          <div class="row">
            
              	<div class="col-md-12">
					<div class="card">
						<div class="card-header p-2">
							<ul class="nav nav-pills">
								<li class="nav-item"><a class="nav-link <?php if($tab == 'edit'): ?> active <?php endif; ?>" href="#edit" data-toggle="tab">Edit Product</a></li>
								<li class="nav-item"><a class="nav-link <?php if($tab == 'price'): ?> active <?php endif; ?>" href="#price" data-toggle="tab">Price</a></li>
								<li class="nav-item"><a class="nav-link <?php if($tab == 'image'): ?> active <?php endif; ?>" href="#image" data-toggle="tab">Image</a></li>
								<li class="nav-item"><a class="nav-link <?php if($tab == 'specification'): ?> active <?php endif; ?>" href="#specification" data-toggle="tab">Specification</a></li>
								<li class="nav-item"><a class="nav-link <?php if($tab == 'feature'): ?> active <?php endif; ?>" href="#feature" data-toggle="tab">Feature</a></li>
							</ul>
						</div>
						<div class="card-body">
							<div class="tab-content">
								<!-- Edit Product -->
								<?php echo $__env->make('admin.product.components.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								<!-- Price -->
								<?php echo $__env->make('admin.product.components.price', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								<!-- Image -->
								<?php echo $__env->make('admin.product.components.image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								<!-- Specification -->
								<?php echo $__env->make('admin.product.components.specification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								<!-- Feature -->
								<?php echo $__env->make('admin.product.components.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
						</div>
					</div>
					<!-- revision history -->
					
					<!-- revision history -->
				</div>

          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
      </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/product/product_edit.blade.php ENDPATH**/ ?>