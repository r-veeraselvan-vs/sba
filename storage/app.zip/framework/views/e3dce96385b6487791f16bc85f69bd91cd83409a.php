<?php $__env->startSection('content'); ?>

  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Rider</h1>
          </div>
        </div>
      </div>
    </section>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Create Rider</h3>
              </div>
              <form role="form" method="post" class="col-md-6" action="<?php echo e(route('rider.save')); ?>">
                  <?php echo csrf_field(); ?>
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter Name" value="<?php echo e(old('name')); ?>">
                    <?php if($errors->has('name')): ?> 
                        <span class="error" for="site" style="display: inline-block;color:red;"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Mobile</label>
                    <input type="text" class="form-control" name="mobile" placeholder="Enter Mobile" value="<?php echo e(old('mobile')); ?>">
                    <?php if($errors->has('mobile')): ?> 
                        <span class="error" for="site" style="display: inline-block;color:red;"><?php echo e($errors->first('mobile')); ?></span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" name="email" placeholder="Enter email" value="<?php echo e(old('email')); ?>">
                    <?php if($errors->has('email')): ?> 
                        <span class="error" for="site" style="display: inline-block;color:red;"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Password">
                    <?php if($errors->has('password')): ?> 
                        <span class="error" for="site" style="display: inline-block;color:red;"><?php echo e($errors->first('password')); ?></span>
                    <?php endif; ?>
                  </div>
                  
                </div>

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Create</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/rider/add_rider.blade.php ENDPATH**/ ?>