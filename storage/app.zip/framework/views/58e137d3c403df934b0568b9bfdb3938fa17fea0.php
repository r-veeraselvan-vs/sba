<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Products List</h1>
          </div>
        </div>
      </div>
    </div>
    <!-- /.content-header -->

    <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <div class="tab-content">

                    <!-- main Service -->
                    <div class="tab-pane active">
                            <div class="row">
                                <div class="col-md-6">
                                    <form action="<?php echo e(route('product.export')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-8">
                                                Choose Category:
                                                <select class="form-control" name="category_id">
                                                    <option value="">All</option>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <button type="submit" id="export-btn" class="btn btn-success btn-sm" >
                                                    <i class="fa fa-download"></i> Export Products</button>
                                            </div>
                                        </div>
                                    </form>
                                    <style>
                                        button#export-btn {
                                            margin-top: 25px;
                                        }
                                    </style>
                                </div>
                                <div class="col-md-6 add-button">
                                    <a type="button" href="<?php echo e(route('product.import')); ?>" class="btn btn-info btn-sm" >
                                        <i class="fa fa-upload"></i> Update Price</a>
                                    <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-lg">Add Product</button>
                                </div>
                            </div>
                        <br>
                        <table id="example1" class="table">
                            <thead>
                                <tr>
                                    <th>Sl No</th>
                                    <th>Category</th>
                                    <th>Subcategory</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Matrix 1</th>
                                    <th>Matrix 2</th>
                                    <th>Average Rating</th>
                                    <th>Rating Count</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($p+1); ?></td>
                                    <td><?php echo e(@$product->category->category); ?></td>
                                    <td><?php echo e($product->subcategory->subcategory); ?></td>
                                    <td>
                                        <a href="<?php echo e($product->ThumbnailUrl); ?>" target="_blank" rel="noopener noreferrer">
                                            <img src="<?php echo e($product->ThumbnailUrl); ?>" height="30px" width="30px">
                                        </a>
                                    </td>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e($product->matrix1); ?></td>
                                    <td><?php echo e($product->matrix2); ?></td>
                                    <td><?php echo e($product->average_ratings); ?></td>
                                    <td><?php echo e($product->ratings_count); ?></td>
                                    <td><span class="right badge <?php if($product->status == 'Active'): ?> badge-success <?php else: ?> badge-danger <?php endif; ?>"><?php echo e($product->status); ?></span></td>
                                    <td>
                                        <a href="<?php echo e(route('product.edit', [ 'id' => $product->id, 'tab' => 'edit' ])); ?>"><span class="badge bg-danger"><i class="fas fa-edit"></i></span></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

               
                </div>
              </div>
            </div>
          </div>

  </div>

  <!-- product add model -->
  <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Products</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form role="form" method="post" class="col-md-12" enctype="multipart/form-data" action="<?php echo e(route('product.save')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-6">

                                <div class="form-group">
                                    <label for="exampleInputPassword1">Category</label>
                                    <select class="form-control" name="category_id" onchange="loadSubcategory();" id="category_id" required>
                                        <option></option>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="exampleInputPassword1">Subcategory</label>
                                    <select class="form-control" name="subcategory_id" id="subcategory_id" required>
                                    </select>
                                </div>
                                 <div class="form-group">
                                    <label for="exampleInputPassword1">Vendors</label>
                                    <select class="form-control" name="vendor_id"   id="vendor_id" required>
                                        <option></option>
                                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Name</label>
                                    <input type="text" required class="form-control" name="name" placeholder="Enter Name">
                                </div>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Matrix 1 (Optional)</label>
                                    <input type="text" class="form-control" name="matrix1" placeholder="Enter Matrix 1">
                                </div>

                                <div class="form-group">
                                    <label for="exampleInputEmail1">Matrix 2 (Optional)</label>
                                    <input type="text" class="form-control" name="matrix2" placeholder="Enter Matrix 2">
                                </div> 

                                <div class="form-group">
                                    <label for="exampleInputEmail1">GST</label>
                                    <input type="number" class="form-control" name="gst" placeholder="Enter GST">
                                </div> 
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Non Returnable</label>
                                            <div class="row">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" value="Yes" name="nonreturnable">
                                                    <label class="form-check-label">Yes</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" checked type="radio" value="No" name="nonreturnable">
                                                    <label class="form-check-label">No</label>
                                                </div>
                                            </div>
                                        </div>  

                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Top Selling</label>
                                            <div class="row">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" value="Yes" name="is_top_selling">
                                                    <label class="form-check-label">Yes</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" checked type="radio" value="No" name="is_top_selling">
                                                    <label class="form-check-label">No</label>
                                                </div>
                                            </div>
                                        </div>  
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Offer</label>
                                            <div class="row">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" value="Yes" name="is_offer">
                                                    <label class="form-check-label">Yes</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" checked value="No" name="is_offer">
                                                    <label class="form-check-label">No</label>
                                                </div>
                                            </div>
                                        </div> 

                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Show In Home Page</label>
                                            <div class="row">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" value="Yes" name="show_in_home">
                                                    <label class="form-check-label">Yes</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" checked value="No" name="show_in_home">
                                                    <label class="form-check-label">No</label>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>  

                                <input type="hidden" name="status" value="Inactive">
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Description</label>
                                    <div class="form-group">
                                        <textarea class="ckeditor form-control" name="description"></textarea>
                                    </div>
                                </div> 
                                
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Thumbnail Image</label>
                                    <div class="input-group">
                                        <div class="custom-file">
                                            <input type="file" required onChange="displayImage(this)" name="thumbnail" class="custom-file-input" id="exampleInputPassword1">
                                            <label class="custom-file-label" for="exampleInputFile">Thumbnail Image</label>
                                        </div>
                                    </div>
                                    <br>                        
                                    <img class="pull-right" src="/images/no_image.png" onClick="triggerClick()" id="profile_display" height="100px" width="100px">
                                </div>

                                <script>
                                function triggerClick(e) {
                                    document.querySelector('#image').click();
                                }
                                function displayImage(e) {
                                    if (e.files[0]) {
                                        var reader = new FileReader();
                                        reader.onload = function(e){
                                        document.querySelector('#profile_display').setAttribute('src', e.target.result);
                                        }
                                        reader.readAsDataURL(e.files[0]);
                                    }
                                }
                                </script>
                                                               
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
  <!-- product add model -->
 
<script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('.ckeditor').ckeditor();
    });

    function loadSubcategory(){
        $('#subcategory_id').empty();
        var category_id = $('#category_id').val();
        var subCatArr = <?php echo json_encode($subcategories, 15, 512) ?>;
        var filteredArray = subCatArr.filter(x => x.category_id == category_id);
        console.log('subcategory', filteredArray);
        $('#subcategory_id').append('<option value="">Select</option>');
        var options = filteredArray.forEach( function(item, index){
            $('#subcategory_id').append('<option value="'+item.id+'">'+item.subcategory+'</option>');
        });
    }

</script>

  <?php $__env->stopSection(); ?>
  


                    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/product/product_list.blade.php ENDPATH**/ ?>