<div class="tab-pane" id="address">
    <div>
        <table class="table table_data">
            <thead>
                <tr>
                    <th>Sl.No</th>
                    <th>Short Name</th>
                    <th>Address</th>
                    <th>Building</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $customer->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i+1); ?></td>
                        <td><?php echo e($address->short_name); ?></td>
                        <td><?php echo e($address->address); ?></td>
                        <td><?php echo e($address->building); ?></td>
                        <td><?php echo e($address->latitude); ?></td>
                        <td><?php echo e($address->longitude); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </tbody>             
        </table>
    </div>
</div><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/customer/components/address.blade.php ENDPATH**/ ?>