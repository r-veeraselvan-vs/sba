<?php $__env->startSection('content'); ?>

<main class="main">
            <div class="page-header" style="background-image: url(images/page-header.jpg)">
                <h1 class="page-title">Refund Policy</h1>
            </div>
            <div class="page-content mt-10 pt-7">
                <section class="about-section">
                    <div class="container">
                        <div class="tab-pane active in" id="product-tab-description">
                            <h5>Refund Policy</h5>
                            <p>Only certain products sold through our website are eligible for return during the return window. Every product in display will display whether it is eligible for return, the eligible conditions for return and the duration of return window. If the product is eligible for return, you can make a return and refund request from your 'Orders' page and every refund request will be processed within 15 days from the date of receipt of goods in original form and shape in our office. Refunds will be done through the original payment mode.</p>
                            <br>
                            <h5>Acceptance of this Refund Policy</h5>
                            <p>It is your responsibility to familiarize yourself with this refund policy.</p>
                            <p>By placing an order with directfarms.biz, you are supposed to have read this refund policy, agreed with and fully accepted the terms of this refund policy.</p>
                            <p>If you do not agree with or fully accept the terms of this refund policy, please don’t purchase any products from our site.</p>
                        </div>
                    </div>
                </section>
                <!-- End About Section-->

            </div>
        </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/customer/front/refund-policy.blade.php ENDPATH**/ ?>