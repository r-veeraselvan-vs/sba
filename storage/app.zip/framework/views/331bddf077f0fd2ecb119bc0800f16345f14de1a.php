
<header class="header header-border">
    <div class="header-middle sticky-header fix-top sticky-content">
        <div class="container">
            <div class="header-left">
                <a href="#" class="mobile-menu-toggle">
                    <i class="d-icon-bars2"></i>
                </a>
            </div>
            <div class="header-center">
                <a href="/" class="logo" style="display: flex; padding-right: 30px;">
                    <img src="<?php echo e(asset('logo/DFLogo1.jpg')); ?>" alt="logo" width="75" height="39" />
                 </a>
                <!-- php -->
                <?php
                    use App\Category;
                    $cats = Category::orderBy('id', 'desc')->where('status', 'Active')->get();
                ?>

                <!-- php -->
                
                <nav class="main-nav" style="padding-left: 40px; ">
                    <ul class="menu">
                        <!-- Home -->
                        <li class="<?php if(request()->segment(1) == ''): ?> active <?php endif; ?>">
                            <a href="/">Home</a>
                        </li>

                        <!-- About Us -->
                        <li class="<?php if(request()->segment(1) == 'about-us'): ?> active <?php endif; ?>">
                            <a href="/about-us">About Us</a>
                        </li>

                        <!-- Contact Us -->
                        <li class="<?php if(request()->segment(1) == 'contact-us'): ?> active <?php endif; ?>">
                            <a href="/contact-us">Contact Us</a>
                        </li>
                        
                         <!-- Categories -->
                        <li class="<?php if(request()->segment(2) == 'categories'): ?> active <?php endif; ?>">
                        <!-- href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => 'all', 'sub_slug' => 'all' ])); ?>" -->
                            <a >Categories</a>
                            <div class="megamenu">
                                <div class="row">
                                    <div class="col-6 col-sm-4 col-md-3 col-lg-4">
                                        <ul>
                                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($c %2 == 0): ?>
                                                    <li><a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $cat->slug, 'sub_slug' => 'all' ])); ?>"><?php echo e($cat->category); ?></a></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <div class="col-6 col-sm-4 col-md-3 col-lg-4">
                                        <ul>
                                            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($c %2 != 0): ?>
                                                    <li><a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => $cat->slug, 'sub_slug' => 'all' ])); ?>"><?php echo e($cat->category); ?></a></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <div
                                        class="col-6 col-sm-4 col-md-3 col-lg-4 menu-banner menu-banner1 banner banner-fixed">
                                        <figure>
                                            <img src="<?php echo e(url('images/menu/banner-1.jpg')); ?>" alt="Menu banner" width="221"
                                                height="330" />
                                        </figure>
                                        <!-- <div class="banner-content y-50">
                                            <h4 class="banner-subtitle font-weight-bold text-primary ls-m">Sale.
                                            </h4>
                                            <h3 class="banner-title font-weight-bold"><span class="text-uppercase">Up
                                                    to</span>70% Off</h3>
                                            <a href="<?php echo e(route('products', [ 'menu' => 'categories', 'slug' => 'all', 'sub_slug' => 'all' ])); ?>" class="btn btn-link btn-underline">shop now<i
                                                    class="d-icon-arrow-right"></i></a>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                        </li>
                        <span class="divider"></span>
                        <!-- End of Divider -->
                        <div class="header-search hs-toggle">
                            <a href="#" class="search-toggle">
                                <i class="d-icon-search"></i>
                            </a>
                            <form action="<?php echo e(route('product.search')); ?>" class="input-wrapper">
                                <input type="text" class="form-control" name="search" autocomplete="off"
                                    placeholder="Search your Products..." />
                                <button class="btn btn-search" type="submit">
                                    <i class="d-icon-search"></i>
                                </button>
                            </form>
                        </div>
                        <!-- End of Header Search -->

                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <?php if(Auth::user()): ?>
                    <a  class="rv" href="<?php echo e(route('customer.profile')); ?>">
                        <i class="d-icon-user"></i>
                        <span><?php echo e(Auth::user()->name); ?></span>
                    </a>
                <?php else: ?>
                    <a class="rv" href="/login">
                        <i class="d-icon-user"></i>
                        <span>Login</span>
                    </a>
                <?php endif; ?>

                <!-- End of Login -->
                <span class="divider"></span>

                <!-- cart -->
                <?php
                    use App\Cart;
                    if(Auth::user()){
                        $user_id = \Auth::user()->id;
                        $query = Cart::where('user_id', $user_id);
                    }else{
                        $session_id = \Session::getId();
                        $query = Cart::where('session_id', $session_id);
                    }
                    $cart_count = $query->count();
                    $cart_amount = $query->sum('amount');
                    $cart_products = $query->with('product')->get();
                ?>

                <div class="dropdown cart-dropdown">
                    <a href="<?php echo e(route('cart')); ?>" class="cart-toggle">
                        <span class="cart-label">
                            <span class="cart-name">My Cart</span>
                            <span class="cart-price">₹<?php echo e(number_format($cart_amount, 2)); ?></span>
                        </span>
                        <i class="minicart-icon">
                            <span class="cart-count"><?php echo e($cart_count); ?></span>
                        </i>
                    </a>
                    <!-- End of Cart Toggle -->
                    <div class="dropdown-box">
                        <?php if(count($cart_products) > 0): ?>
                            <div class="product product-cart-header">
                                <span class="product-cart-counts"><?php echo e($cart_count); ?> items</span>
                                <span><a href="<?php echo e(route('cart')); ?>">View cart</a></span>
                            </div>
                            <div class="products scrollable">
                                <!-- End of Cart Product -->
                                <?php $__currentLoopData = $cart_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        $product_price = ($cp->offer_price > 0) ? $cp->offer_price : $cp->price;
                                        $productUrl =  route('product.details', [ 'price_id' => $cp->product_price_id, 'slug' => $cp->product->slug ]);
                                    ?>

                                    <div class="product product-cart">
                                        <div class="product-detail">
                                            <a href="<?php echo e($productUrl); ?>" class="product-name"><?php echo e(@$cp->product->name); ?></a>
                                            <div class="price-box">
                                                <span class="product-quantity"><?php echo e(@$cp->quantity); ?></span>
                                                <span class="product-price">₹ <?php echo e(number_format($product_price, 2)); ?></span>
                                            </div>
                                        </div>
                                        <figure class="product-media">
                                            <a href="<?php echo e($productUrl); ?>">
                                                <img src="<?php echo e(@$cp->product->ThumbnailUrl); ?>" alt="product" width="90" height="90" />
                                            </a>
                                            <a href="<?php echo e(route('cart.remove', [ 'cart_id' => $cp->id ])); ?>" class="btn btn-link btn-close">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        </figure>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- End of Cart Product -->
                            </div>
                            <!-- End of Products  -->
                            <div class="cart-total">
                                <label>Subtotal:</label>
                                <span class="price">₹ <?php echo e(number_format($cart_amount, 2)); ?></span>
                            </div>
                        <?php else: ?>
                            <h5>Your cart is Empty</h5>
                        <?php endif; ?>
                        <!-- End of Cart Total -->
                        <div class="cart-action">
                            <?php if(count($cart_products) > 0): ?>
                                <a href="<?php echo e(route('cart.checkout')); ?>" class="btn btn-dark"><span>Checkout</span></a>
                            <?php else: ?>
                                <a href="/" class="btn btn-light"><span>Continue Shopping</span></a>
                            <?php endif; ?>
                        </div>
                        <!-- End of Cart Action -->
                    </div>
                    <!-- End of Dropdown Box -->
                </div>
                <!-- cart -->

            </div>
        </div>
    </div>
</header><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/layouts/front/header.blade.php ENDPATH**/ ?>