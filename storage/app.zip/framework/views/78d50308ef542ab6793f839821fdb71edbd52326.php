
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
		<title>Madurai Kadai</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
		<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/jqvmap/jqvmap.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/adminlte.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/summernote/summernote-bs4.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.css')); ?>">
		<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

		<!-- Select 2 Css -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
		<!-- jQuery -->
		<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
	</head>
	<body class="hold-transition sidebar-mini layout-fixed">
		<div class="wrapper">
			<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<?php echo $__env->yieldContent('content'); ?>
			<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<aside class="control-sidebar control-sidebar-dark">
			</aside>
		</div>
		<script src="<?php echo e(asset('assets/plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
		<script> $.widget.bridge('uibutton', $.ui.button); </script>
		<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/chart.js/Chart.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/sparklines/sparkline.js')); ?>"></script>
		<!-- <script src="<?php echo e(asset('assets/plugins/jqvmap/jquery.vmap.min.js')); ?>"></script> -->
		<!-- <script src="<?php echo e(asset('assets/plugins/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script> -->
		<script src="<?php echo e(asset('assets/plugins/jquery-knob/jquery.knob.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/moment/moment.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/summernote/summernote-bs4.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/dist/js/adminlte.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/dist/js/pages/dashboard.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/dist/js/demo.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
			
		<!-- Toaster -->
		<script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
		<?php echo Toastr::message(); ?>

		<link rel="stylesheet" href="https://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
		<!-- Toaster -->
        <!-- DataTables -->
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">
<script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js"></script> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.html5.min.js"></script>

<!-- Select 2 -->
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script>
    $(function () {
      $(".table_data").DataTable({
        "responsive": true,
        "autoWidth": false,
      });
      $("#example1").DataTable({
        "responsive": true,
        "autoWidth": false,
      });

      $('#example2').DataTable({
        "autoWidth": false,
        "responsive": true,
      });
      
      $("#example11").DataTable({
        "responsive": true,
        "autoWidth": false,
      });   

    });

  </script>





  <style>
div#example1_filter {
    float: right;
}
div#export_filter {
    float: right;
}
div#example11_filter {
    float: right;
}
div#example1_paginate {
    float: right;
}
div#export_paginate {
    float: right;
}
div#example11_paginate {
    float: right;
}

.add-button {
    text-align: right;
}

.form-check {
    padding-left: 2.25rem !important;
}

.table
{
word-wrap: break-word;
word-break: break-all;  
white-space: normal !important;
text-align: justify;
}


.dataTables_wrapper .dataTables_paginate .paginate_button {
    padding: 0px !important;
}
  </style>
	</body>
</html>
<?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/layouts/app.blade.php ENDPATH**/ ?>