<div class="tab-pane <?php if($tab == 'edit'): ?> active <?php endif; ?>" id="edit">    
    <div>
        <form role="form" method="post" class="col-md-12" enctype="multipart/form-data" action="<?php echo e(route('product.update')); ?>">
            <?php echo csrf_field(); ?>

            <div class="row">
                <div class="col-md-6">
                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                    <input type="hidden" name="old_thumbnail" value="<?php echo e($product->thumbnail); ?>">
                    <input type="hidden" name="tab" value="<?php echo e($tab); ?>">

                    <div class="form-group">
                        <label for="exampleInputPassword1">Category</label>
                        <select class="form-control" name="category_id" onchange="loadSubcategory();" id="category_id" required>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php if($category->id == $product->category_id): ?> selected <?php endif; ?>><?php echo e($category->category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="exampleInputPassword1">Subcategory</label>
                        <select class="form-control" name="subcategory_id" id="subcategory_id" required>
                        </select>
                    </div>
                    <div class="form-group">
                                    <label for="exampleInputPassword1">Vendors</label>
                                    <select class="form-control" name="vendor_id"   id="vendor_id" required>
                                        <option></option>
                                        <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($vendor->id); ?>" <?php if($vendor->id == $product->vendor_id): ?> selected <?php endif; ?>><?php echo e($vendor->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                    <div class="form-group">
                        <label for="exampleInputEmail1">Name</label>
                        <input type="text" required class="form-control" name="name" value="<?php echo e($product->name); ?>" placeholder="Enter Name">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputPassword1">Matrix 1 (Optional)</label>
                        <input type="text" class="form-control" name="matrix1" value="<?php echo e($product->matrix1); ?>" placeholder="Enter Matrix 1">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputPassword1">Matrix 2 (Optional)</label>
                        <input type="text" class="form-control" name="matrix2" value="<?php echo e($product->matrix2); ?>" placeholder="Enter Matrix 2">
                    </div>

                    <div class="form-group">
                        <label for="exampleInputPassword1">GST</label>
                        <input type="number" class="form-control" name="gst" value="<?php echo e($product->gst); ?>" placeholder="Enter GST">
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Non Returnable</label>
                                <div class="row">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" <?php if($product->nonreturnable == 'Yes'): ?> checked <?php endif; ?> value="Yes" name="nonreturnable">
                                        <label class="form-check-label">Yes</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" <?php if($product->nonreturnable == 'No'): ?> checked <?php endif; ?> value="No" name="nonreturnable">
                                        <label class="form-check-label">No</label>
                                    </div>
                                </div>
                            </div>  
                            <div class="form-group">
                                <label for="exampleInputEmail1">Offer</label>
                                <div class="row">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" <?php if($product->is_offer == 'Yes'): ?> checked <?php endif; ?> value="Yes" name="is_offer">
                                        <label class="form-check-label">Yes</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" <?php if($product->is_offer == 'No'): ?> checked <?php endif; ?> value="No" name="is_offer">
                                        <label class="form-check-label">No</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Top Selling</label>
                                <div class="row">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" <?php if($product->is_top_selling == 'Yes'): ?> checked <?php endif; ?> value="Yes" name="is_top_selling">
                                        <label class="form-check-label">Yes</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" <?php if($product->is_top_selling == 'No'): ?> checked <?php endif; ?> value="No" name="is_top_selling">
                                        <label class="form-check-label">No</label>
                                    </div>
                                </div>
                            </div>
                                
                            <div class="form-group">
                                <label for="exampleInputEmail1">Show In Home Page</label>
                                <div class="row">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" <?php if($product->show_in_home == 'Yes'): ?> checked <?php endif; ?> value="Yes" name="show_in_home">
                                        <label class="form-check-label">Yes</label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" <?php if($product->show_in_home == 'No'): ?> checked <?php endif; ?> value="No" name="show_in_home">
                                        <label class="form-check-label">No</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                        
                      
                        
                    
                    
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                                             
                </div>           
                <div class="col-md-6">
                   
                    <div class="form-group">
                        <label for="exampleInputEmail1">Description</label>
                        <div class="form-group">
                            <textarea class="ckeditor form-control" name="description"><?php echo $product->description; ?></textarea>
                        </div>
                    </div>     

                    <div class="form-group">
                        <label for="exampleInputPassword1">Thumbnail Image</label>
                        <div class="input-group">
                            <div class="custom-file">
                                <input type="file" onChange="displayImage(this)" name="thumbnail" class="custom-file-input" id="exampleInputPassword1">
                                <label class="custom-file-label" for="exampleInputFile">Choose Image</label>
                            </div>
                        </div>
                        <br>                        
                        <img class="pull-right" src="<?php echo e($product->ThumbnailUrl); ?>" onClick="triggerClick()" id="profile_display" height="100px" width="100px">
                    </div>

                    <script>
                    function triggerClick(e) {
                        document.querySelector('#image').click();
                    }
                    function displayImage(e) {
                        if (e.files[0]) {
                            var reader = new FileReader();
                            reader.onload = function(e){
                            document.querySelector('#profile_display').setAttribute('src', e.target.result);
                            }
                            reader.readAsDataURL(e.files[0]);
                        }
                    }
                    </script> 
                    
                    <div class="form-group">
                        <label for="exampleInputPassword1">Status</label>
                        <select class="form-control" name="status" >
                            <option value="Active" <?php if('Active' == $product->status): ?> selected <?php endif; ?>>Active</option>
                            <option value="Inactive" <?php if('Inactive' == $product->status): ?> selected <?php endif; ?>>Inactive</option>
                        </select>
                    </div>
                </div>
            </div> 
            
        </form>
    </div>
</div>

<script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('.ckeditor').ckeditor();
        });

     onLoadSubcategory();

    function onLoadSubcategory(){
        $('#subcategory_id').empty();
        var category_id = "<?php echo e($product->category_id); ?>";
        var subCatArr = <?php echo json_encode($subcategories, 15, 512) ?>;
        var filteredArray = subCatArr.filter(x => x.category_id == category_id);
        console.log('subcategory', filteredArray);
        $('#subcategory_id').append('<option value="">Select</option>');
        var options = filteredArray.forEach( function(item, index){
            var sel = '';
            if("<?php echo e($product->subcategory_id); ?>" == item.id){
                var sel = 'selected';
            }
            $('#subcategory_id').append('<option value="'+item.id+'"'+sel+'>'+item.subcategory+'</option>');
        });
    }

    function loadSubcategory(){
        $('#subcategory_id').empty();
        var category_id = $('#category_id').val();
        var subCatArr = <?php echo json_encode($subcategories, 15, 512) ?>;
        var filteredArray = subCatArr.filter(x => x.category_id == category_id);
        console.log('subcategory', filteredArray);
        $('#subcategory_id').append('<option value="">Select</option>');
        var options = filteredArray.forEach( function(item, index){
            $('#subcategory_id').append('<option value="'+item.id+'">'+item.subcategory+'</option>');
        });
    }

</script><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/product/components/edit.blade.php ENDPATH**/ ?>