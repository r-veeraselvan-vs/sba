<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
    <title > <?php echo e(@$title ? @$title.' | ' : ''); ?> <?php echo e(config("app.name") ? config("app.name") : 'Madurai Kadai'); ?></title>

    <meta name="keywords" content="<?php echo e(@$title); ?>" id="keywords" />
    <meta name="description" content="<?php echo e(@$title); ?>" id="description">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/icons/favicon.png')); ?>">

    <script>
        WebFontConfig = {
            google: {
                families: ['Open+Sans:400,600,700', 'Poppins:400,600,700']
            }
        };
        (function(d) {
            var wf = d.createElement('script'),
                s = d.scripts[0];
            wf.src = '/js/webfont.js';
            wf.async = true;
            s.parentNode.insertBefore(wf, s);
        })(document);
    </script>



    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/animate/animate.min.css')); ?>">

    <!-- Plugins CSS File -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/magnific-popup/magnific-popup.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/photoswipe/photoswipe.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendor/photoswipe/default-skin/default-skin.min.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/demo1.min.css')); ?>">
    <style>
        .carousel-inner>.item>a>img, .carousel-inner>.item>img, .img-responsive, .thumbnail a>img, .thumbnail>img {
            aspect-ratio: 501 / 173;
    object-fit: cover;
        }
        .owl-carousel .owl-item img {
    display: block;
    width: 100%;
    aspect-ratio: 1000 / 563;
    object-fit: contain;
}
.product-media img {
    display: block;
    width: 100%;
    height: auto;
    transition: all .5s;
    aspect-ratio: 1000 / 563;
    object-fit: contain;
}
    </style>
</head>

<body class="home">
    <!-- <div class="loading-overlay">
        <div class="bounce-loader">
            <div class="bounce1"></div>
            <div class="bounce2"></div>
            <div class="bounce3"></div>
            <div class="bounce4"></div>
        </div>
    </div> -->
    <div class="page-wrapper">
        <h1 class="d-none">Thought Feast</h1>

        <?php echo $__env->make('layouts.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('layouts.front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.front.sticky-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Scroll Top -->
    <a id="scroll-top" href="#top" title="Top" role="button" class="scroll-top"><i class="fas fa-chevron-up"></i></a>

    <?php echo $__env->make('layouts.front.mobile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    

</body>

<!-- Plugins JS File -->
<script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/parallax/parallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/imagesloaded/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/elevatezoom/jquery.elevatezoom.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/photoswipe/photoswipe.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/photoswipe/photoswipe-ui-default.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>

<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.min.js')); ?>"></script>
<!-- Main JS File -->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

</html><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/layouts/app-front.blade.php ENDPATH**/ ?>