<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
      <img src="https://youthechef.com/logo/DFLogo1.jpg" alt="Madurai Kadai Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">Madurai Kadai</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) 
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="/assets/dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo e(ucfirst(Auth::user()->name)); ?></a>
        </div>
      </div>-->

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
            <li class="nav-item">
                <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'dashboard') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-tachometer-alt"></i>
                <p> Dashboard</p>
                </a>
            </li>

            <li class="nav-item has-treeview <?php echo e((request()->segment(2) == 'user') ? 'menu-open' : ''); ?>">
                <a href="#" class="nav-link <?php echo e((request()->segment(2) == 'user') ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-users"></i>
                    <p> Users <i class="fas fa-angle-left right"></i> </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('user.create')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'user') && (request()->segment(3) == 'create') ? 'active' : ''); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Add User</p>
                        </a>
                    </li>
                </ul>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('user.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'user') && (request()->segment(3) == 'list') ? 'active' : ''); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>User List</p>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo e((request()->segment(2) == 'vendor') ? 'menu-open' : ''); ?>">
                <a href="#" class="nav-link <?php echo e((request()->segment(2) == 'vendor') ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-users"></i>
                    <p> Vendors <i class="fas fa-angle-left right"></i> </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('vendor.create')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'vendor') && (request()->segment(3) == 'create') ? 'active' : ''); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Add Vendor</p>
                        </a>
                    </li>
                </ul>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="<?php echo e(route('vendor.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'vendor') && (request()->segment(3) == 'list') ? 'active' : ''); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Vendors List</p>
                        </a>
                    </li>
                </ul>
            </li>


            <li class="nav-item">
                <a href="<?php echo e(route('customer.list')); ?>" class="nav-link <?php echo e(((request()->segment(2) == 'customer') && (request()->segment(3) == 'list' || request()->segment(3) == 'view') || (request()->segment(2) == 'notification' && request()->segment(3) == 'customer') ) ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-newspaper"></i>
                <p>Customers</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('rider.list')); ?>" class="nav-link <?php echo e(((request()->segment(2) == 'rider') && (request()->segment(3) == 'list' || request()->segment(3) == 'view' || request()->segment(3) == 'create') || (request()->segment(2) == 'notification' && request()->segment(3) == 'rider') ) ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-newspaper"></i>
                <p>Riders</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('setting.edit')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'settings') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-cog"></i>
                <p> Settings</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('billing.add')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'billing') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-money-bill"></i>
                <p> Billing</p>
                </a>
            </li>
            
        <li class="nav-header">Configuration</li>

            <li class="nav-item">
                <a href="<?php echo e(route('category.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'category') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-list-alt"></i>
                <p> Category</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('subcategory.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'subcategory') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-list-alt"></i>
                <p> Subcategory</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('banner.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'banner') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-clock"></i>
                <p> Banner</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('mobile.banner.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'mobile-banner') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-clock"></i>
                <p> Mobile Banner</p>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="<?php echo e(route('news.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'news') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-list"></i>
                <p> News</p>
                </a>
            </li>
            
            <li class="nav-item">
                <a href="<?php echo e(route('product.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'product') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-book"></i>
                <p> Products</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('delivery.area.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'delivery-area') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-map-marker"></i>
                <p> Delivery Area</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('delivery.slot.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'delivery-slot') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-list"></i>
                <p> Delivery Slot</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('promocode.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'promocode') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-circle"></i>
                <p> Promocode</p>
                </a>
            </li>

            <li class="nav-header">Orders</li>

            <li class="nav-item">
                <a href="<?php echo e(route('order.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'order'&& (request()->segment(3) != 'customer' && request()->segment(3) != 'summary')) ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-newspaper"></i>
                <p> Orders Received</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('order.customers')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'order' && request()->segment(3) == 'customer') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-newspaper"></i>
                <p>Customer Orders</p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('order.summary')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'order' && request()->segment(3) == 'summary') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-newspaper"></i>
                <p>Order Summary</p>
                </a>
            </li>
            
            <li class="nav-header">Reviews</li>

            <li class="nav-item">
                <a href="<?php echo e(route('review.list')); ?>" class="nav-link <?php echo e((request()->segment(2) == 'review') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-star"></i>
                <p> Customer Reviews</p>
                </a>
            </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
<?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>