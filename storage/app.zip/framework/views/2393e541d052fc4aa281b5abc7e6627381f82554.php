<?php $__env->startSection('content'); ?>
<main class="main account">
    <div class="page-header" style="background-image: url('/images/page-header.jpg'); background-color: #3C63A4;">
        <h1 class="page-title">Reset Password</h1>
    </div>
    <!-- End PageHeader -->
    <div class="col-md-12">
        <div class="row login-form">
            <div class="col-md-3"></div>
            <div class="login-popup col-md-6">
                <div class="form-box">
                    <h4>Reset Password</h4>
                    <div class="tab-pane active" id="signin">
                        <form class="login100-form" method="POST" action="<?php echo e(route('password.email')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Email</label>
                                <input class="form-control" type="text" name="email" placeholder="Email address...">
                            </div>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-footer">
                                <div class="form-checkbox">
                                    <input type="checkbox" class="custom-checkbox" id="signin-remember"
                                        name="signin-remember" />
                                </div>
                                <a href="<?php echo e(url('login')); ?>" class="lost-link font-secondary">Login</a>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">
                                Send Password Reset Link
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
</main>

<style>
.login-popup {
    max-width: none;
}
</style>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>