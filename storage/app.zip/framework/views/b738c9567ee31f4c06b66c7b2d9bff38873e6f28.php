<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 193px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Subcategory </h1>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-5">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Edit </h3>
                        </div>
                        <form role="form" method="post" class="col-md-12" enctype="multipart/form-data"
                            action="<?php echo e(route('subcategory.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($subcategory->id); ?>">

							<div class="form-group">
								<label for="exampleInputPassword1">Category</label>
								<select class="form-control" name="category_id" >
									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($category->id); ?>" <?php if($category->id == $subcategory->category_id): ?> selected <?php endif; ?>><?php echo e($category->category); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Subcategory</label>
                                <input type="text" required class="form-control" value="<?php echo e($subcategory->subcategory); ?>"
                                    name="subcategory" placeholder="Enter Subcategory">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputPassword1">Status</label>
                                <select class="form-control" name="status">
                                    <option value="Active" <?php if('Active'==$subcategory->status): ?> selected <?php endif; ?>>Active</option>
                                    <option value="Inactive" <?php if('Inactive'==$subcategory->status): ?> selected <?php endif; ?>>Inactive</option>
                                </select>
                            </div>

                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                        </form>
                    </div>

                </div>
                <div class="col-md-7">

                </div>

            </div>
        </div>
</div>
</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992168876/domains/youthechef.com/public_html/resources/views/admin/subcategory/subcategory_edit.blade.php ENDPATH**/ ?>